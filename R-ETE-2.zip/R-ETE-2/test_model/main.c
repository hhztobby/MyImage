#include "model.h"
#include "weights.h"
#include "data_loader.h"
#include "inputs.h"
#include <stdio.h>
#include <stddef.h>
#include <time.h>
#include <stdlib.h>

int main(){
    // float test_input[IN_DIM];
    // int train_label = 2;
    // for(int i=0; i<IN_DIM; ++i){
    //     test_input[i] = (float)i*0.01; 
    //     printf("%.5f ",test_input[i]);
    // }
    // printf("\n");


    float* input_buffer = get_input();
    float* output_buffer = get_output();
    clock_t begin,end;

    // for(int i=0; i< IN_DIM; ++i){
    //     input_buffer[i] = test_input[i];
    //     printf("%.5f ",input_buffer[i]);
    // }

    fixed_cyclic_loader(Inputs_fine_tune_data,
                    input_buffer,NULL,NULL,
                    0,1,2048);
    // printf("\n");
    begin = clock();
    
    forward(1, NULL);

    end = clock();

    printf("exe_Time: %ld micro sec\n", (long)(end - begin));

    printf("\n");

    for(int i=0; i<3; ++i){
        printf("%.5f ",output_buffer[i]);
    }
    printf("\n");
    
    fixed_cyclic_loader(Inputs_fine_tune_data,
                        input_buffer,NULL,NULL,
                        1,1,2048);
    // printf("\n");
    begin = clock();
    
    forward(1, NULL);

    end = clock();

    printf("exe_Time: %ld micro sec\n", (long)(end - begin));

    printf("\n");

    for(int i=0; i<3; ++i){
        printf("%.5f ",output_buffer[i]);
    }
    printf("\n");


    printf("Start Training!\n");
    begin = clock();
    for (int e=0; e<800; ++e){
        float total_loss=0.;
        int* batch_labels=(int*)malloc(MAX_BATCH_SIZE*sizeof(int));
        int batch_size=MAX_BATCH_SIZE;
        for (int index=0; index<TOTAL_SAMPLE_NUM; index+=MAX_BATCH_SIZE){
            batch_size = fixed_cyclic_loader(Inputs_fine_tune_data,
                input_buffer,Inputs_fine_tune_label,batch_labels,
                index,MAX_BATCH_SIZE,2048);
        

            total_loss+=batch_size*train(batch_labels,input_buffer,batch_size,2048,1e-4);


            // printf("\n");
        }
        printf("epoch: %d, loss: %.7f\n", e, total_loss/TOTAL_SAMPLE_NUM);
    }
    end = clock();

    printf("exe_Time: %ld micro sec\n", (long)(end - begin));


    // inference again
    // fixed_cyclic_loader(Inputs_fine_tune_data,
    //                     input_buffer,NULL,NULL,
    //                     1,1,2048);
    
    // forward(1, NULL);

    // for(int i=0; i<3; ++i){
    //     printf("%.5f ",output_buffer[i]);
    // }
    // printf("\n");

    return 0;
}