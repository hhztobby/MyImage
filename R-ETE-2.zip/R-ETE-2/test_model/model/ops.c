#include "model.h"
#include <stdint.h>

int8_t buffer[100844];

float* get_input(){
	return (float*)(&buffer[47340]);
}
float* get_output(){
	return (float*)(&buffer[47340]);
}

float forward(int batch_size, int* ground_truth_idx){
	stft((float*)(&buffer[47340]), stft_hann_window, (float*)(&buffer[88300]), (float*)(&buffer[0]), batch_size, 2048, 128, 64, 128);
	conv1d_inf((float*)(&buffer[0]), conv1d_filter, conv1d_bias, (float*)(&buffer[40300]), batch_size, 65, 16, 31, 3, 2, 1, 1);
	relu_inf_in_place((float*)(&buffer[40300]), (int8_t*)(&buffer[45580]), batch_size, 256);
	conv1d_inf((float*)(&buffer[40300]), conv1d_1_filter, conv1d_1_bias, (float*)(&buffer[87020]), batch_size, 16, 8, 16, 3, 2, 0, 1);
	relu_inf_in_place((float*)(&buffer[87020]), (int8_t*)(&buffer[46860]), batch_size, 64);
	maxpool1d_inf((float*)(&buffer[87020]), (float*)(&buffer[45420]), (int*)(&buffer[47180]), batch_size, 8, 9, 8, 9, 0, 1);
	fc_inf((float*)(&buffer[45420]), dense_weight, dense_bias, (float*)(&buffer[47340]), batch_size, 1, 8, 3);
	float result = fused_kldiv_softmax_inf_in_place((float*)(&buffer[47340]), ground_truth_idx, batch_size, 3);
	return result;
}

float train(int* ground_truth_idx, float* training_data, int batch_size, int sample_size, float lr){
	float* net_input = get_input();
	if (net_input!=training_data){
		for(int d=0; d<sample_size*batch_size; ++d) net_input[d]=training_data[d];
	} // else the training data are loaded in place.
	float result=forward(batch_size, ground_truth_idx);
	backward(batch_size, ground_truth_idx, lr);
	return result;
}

void backward(int batch_size, int* ground_truth_idx, float lr){
	fused_kldiv_softmax_grad_path((float*)(&buffer[47340]), ground_truth_idx, batch_size, 3);
	fc_weight_grad((float*)(&buffer[47340]), (float*)(&buffer[45420]), dense_weight, (float*)(&buffer[88300]), batch_size, 1, 8, 3);
	fc_bias_grad((float*)(&buffer[47340]), (float*)(&buffer[45420]), dense_bias, (float*)(&buffer[88396]), batch_size, 1, 8, 3);
	fc_grad_path((float*)(&buffer[47340]), dense_weight, (float*)(&buffer[45420]), batch_size, 1, 8, 3);
	fc_weight_sgd(dense_weight, (float*)(&buffer[88300]), lr, batch_size, 8, 3);
	fc_bias_sgd(dense_bias, (float*)(&buffer[88396]), lr, batch_size, 3);
	maxpool1d_grad_path((float*)(&buffer[45420]), (int*)(&buffer[47180]), (float*)(&buffer[87020]), batch_size, 8, 9, 8, 9, 0, 1);
	relu_grad_path_in_place((float*)(&buffer[87020]), (int8_t*)(&buffer[46860]), batch_size, 64);
	conv1d_weight_grad((float*)(&buffer[87020]), (float*)(&buffer[40300]), conv1d_1_filter, (float*)(&buffer[88300]), batch_size, 16, 8, 16, 3, 2, 0, 1);
	conv1d_bias_grad((float*)(&buffer[87020]), (float*)(&buffer[40300]), conv1d_1_bias, (float*)(&buffer[89836]), batch_size, 16, 8, 16, 3, 2, 0, 1);
	conv1d_grad_path((float*)(&buffer[87020]), conv1d_1_filter, (float*)(&buffer[40300]), batch_size, 16, 8, 16, 3, 2, 0, 1);
	conv1d_weight_sgd(conv1d_1_filter, (float*)(&buffer[88300]), lr, batch_size, 3, 16, 8);
	conv1d_bias_sgd(conv1d_1_bias, (float*)(&buffer[89836]), lr, batch_size, 8);
	relu_grad_path_in_place((float*)(&buffer[40300]), (int8_t*)(&buffer[45580]), batch_size, 256);
	conv1d_weight_grad((float*)(&buffer[40300]), (float*)(&buffer[0]), conv1d_filter, (float*)(&buffer[88300]), batch_size, 65, 16, 31, 3, 2, 1, 1);
	conv1d_bias_grad((float*)(&buffer[40300]), (float*)(&buffer[0]), conv1d_bias, (float*)(&buffer[100780]), batch_size, 65, 16, 31, 3, 2, 1, 1);
	conv1d_grad_path((float*)(&buffer[40300]), conv1d_filter, (float*)(&buffer[0]), batch_size, 65, 16, 31, 3, 2, 1, 1);
	conv1d_weight_sgd(conv1d_filter, (float*)(&buffer[88300]), lr, batch_size, 3, 65, 16);
	conv1d_bias_sgd(conv1d_bias, (float*)(&buffer[100780]), lr, batch_size, 16);
}

