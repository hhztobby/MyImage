#include <stddef.h>
#include "data_loader.h"

int32_t fixed_cyclic_loader_itr_list[15]={0,7,14,6,13,5,12,4,11,3,10,2,9,1,8};
int fixed_cyclic_loader(float* total_samples, float* batch_buffer, int* total_labels, int* batch_labels, int index, int max_batch_size, int sample_size){
	for (int b=index; b<index+max_batch_size && b<TOTAL_SAMPLE_NUM; ++b){
		float* indexed_buffer = &total_samples[fixed_cyclic_loader_itr_list[b]*sample_size];
		for (int d=0; d<sample_size; ++d) batch_buffer[d]=indexed_buffer[d];
		batch_buffer += sample_size;
		if (total_labels!=NULL) batch_labels[b-index]=total_labels[fixed_cyclic_loader_itr_list[b]];
	}
	return (index+max_batch_size>TOTAL_SAMPLE_NUM)?(TOTAL_SAMPLE_NUM-index):max_batch_size;
}

