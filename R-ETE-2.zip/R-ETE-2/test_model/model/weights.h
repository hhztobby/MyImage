#ifndef WEIGHT_H_
#define WEIGHT_H_

#include <stdint.h>

extern float stft_hann_window[128];
extern float conv1d_filter[3120];
extern float conv1d_bias[16];
extern float conv1d_1_filter[384];
extern float conv1d_1_bias[8];
extern float dense_weight[24];
extern float dense_bias[3];
#endif

