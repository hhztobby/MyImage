#ifndef DATA_LOADER_H_
#define DATA_LOADER_H_

#define LOADER_BASE 7
#define TOTAL_SAMPLE_NUM 15
extern int fixed_cyclic_loader_itr_list[15];
int fixed_cyclic_loader(float* total_samples, float* batch_buffer, int* total_labels, int* batch_labels, int index, int max_batch_size, int sample_size);

#endif

