import numpy as np
from preprocess.preprocess import preprocess
import keras
import tensorflow as tf

if __name__ == "__main__":
    file = open("test_model/debug.txt","wt")
    data_dict = np.load("compiler/frontend_model/fine_tune.npy",allow_pickle=True).item()
    feat0 = data_dict["fine_tune_data"][0:2]
    print(feat0.shape)
    fft_res, freq_bins=preprocess(feat0)
    # [[print("{row} {col} {data:.5f}".format(row=row, col=col, data=fft_res[1][row][col].item()),file=file) for col in range(fft_res.shape[2])] for row in range(fft_res.shape[1])]
    print(fft_res.shape, freq_bins.shape)

    # test forward
    layer_name="max_pooling1d"
    model=keras.saving.load_model("compiler/frontend_model/fine_tune.h5")
    layer_debug=keras.Model(inputs=model.input, outputs=model.get_layer(layer_name).output)
    fft_out = np.expand_dims(fft_res[1],axis=0)
    layer_res = layer_debug.predict(fft_out)
    [[print("{row} {col} {data:.5f}".format(row=row, col=col, data=layer_res[0][row][col].item()),file=file) for col in range(layer_res.shape[2])] for row in range(layer_res.shape[1])]
    print(model.predict(fft_out))

    # test backward
    for layer in model.layers:
        layer.trainable=True
    with tf.GradientTape() as tape:
        y_pred = model(fft_res, training=False)  # Forward pass
        # Compute the loss value
        # (the loss function is configured in `compile()`)
        loss = tf.keras.losses.sparse_categorical_crossentropy(np.array([[2],[2]]), y_pred)
        trainable_vars = model.trainable_variables
        gradients_plus = tape.gradient(loss, trainable_vars)
        [print(t.shape, t) for t in gradients_plus]

    # test training
    # weight, bias = model.get_layer(layer_name).get_weights()
    # print(weight)
    model.compile(optimizer=tf.keras.optimizers.SGD(learning_rate=1e-4),
            loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=False),
            metrics=tf.keras.metrics.SparseCategoricalAccuracy(),
            )
    fft_all, _=preprocess(data_dict["fine_tune_data"])
    # idx=[0,7,14,6,13]
    # dataset=tf.data.Dataset.from_tensor_slices((fft_all[idx],data_dict["fine_tune_label"][idx])).batch(batch_size=5)
    # model.fit(dataset,epochs=1)
    idx=[0,7,14,6,13,5,12,4,11,3,10,2,9,1,8]
    idx=np.arange(0,15,1)
    dataset=tf.data.Dataset.from_tensor_slices((fft_all[idx],data_dict["fine_tune_label"][idx])).batch(batch_size=5)
    model.fit(dataset,epochs=800)
    # res=model.predict(fft_all[idx])
    # print(res)
    # new_weight, new_bias = model.get_layer(layer_name).get_weights()
    # print(new_bias-bias)