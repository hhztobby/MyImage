#include "hal_data.h"
/* The part of declaration can be moved to the header. */

#include "sio_char.h"
#include <stdio.h>

FSP_CPP_HEADER
void R_BSP_WarmStart(bsp_warm_start_event_t event);
FSP_CPP_FOOTER
void handle_error_sci_uart (fsp_err_t err);
void user_uart_callback (uart_callback_args_t * p_args);
void r_sci_uart_baud_example (void);

uint8_t  g_out_of_band_received[TRANSFER_LENGTH];
volatile uint32_t g_transfer_complete = 0;
volatile uint32_t g_receive_complete  = 0;
uint32_t g_out_of_band_index = 0;

void setup_sci_uart (void);

void r_sci_uart_baud_example (void)
{
    baud_setting_t baud_setting;
    uint32_t       baud_rate                 = SCI_UART_BAUDRATE_19200;
    bool           enable_bitrate_modulation = false;
    uint32_t       error_rate_x_1000         = 5000;
    fsp_err_t err = R_SCI_UART_BaudCalculate(baud_rate, enable_bitrate_modulation, error_rate_x_1000, &baud_setting);
    handle_error_sci_uart(err);
    err = R_SCI_UART_BaudSet(&g_uart0_ctrl, (void *) &baud_setting);
    handle_error_sci_uart(err);
}

void user_uart_callback (uart_callback_args_t * p_args)
{
    /* Handle the UART event */
    switch (p_args->event)
    {
        /* Received a character */
        case UART_EVENT_RX_CHAR:
        {
            /* Only put the next character in the receive buffer if there is space for it */
            if (sizeof(g_out_of_band_received) > g_out_of_band_index)
            {
                /* Write either the next one or two bytes depending on the receive data size */
                if (UART_DATA_BITS_8 >= g_uart0_cfg.data_bits)
                {
                    g_out_of_band_received[g_out_of_band_index++] = (uint8_t) p_args->data;
                }
                else
                {
                    uint16_t * p_dest = (uint16_t *) &g_out_of_band_received[g_out_of_band_index];
                    *p_dest              = (uint16_t) p_args->data;
                    g_out_of_band_index += 2;
                }
            }
            break;
        }
        /* Receive complete */
        case UART_EVENT_RX_COMPLETE:
        {
            g_receive_complete = 1;
            break;
        }
        /* Transmit complete */
        case UART_EVENT_TX_COMPLETE:
        {
            g_transfer_complete = 1;
            break;
        }
        default:
        {
        }
    }
}


void handle_error_sci_uart (fsp_err_t err)
{
    FSP_PARAMETER_NOT_USED(err);
}

/*******************************************************************************************************************//**
 * @brief  SCI_UART example application
 *
 * Sample program for serial communication.
 * After outputting Hello world, the received character is echoed back.
 *
 **********************************************************************************************************************/
void setup_sci_uart (void)
{
    /* Open the transfer instance with initial configuration. */
    fsp_err_t err = R_SCI_UART_Open(&g_uart0_ctrl, &g_uart0_cfg);
    handle_error_sci_uart(err);
    r_sci_uart_baud_example();

    __asm volatile ("cpsie i");

}

#define TIMER_MIRCOSEC_PER_SEC 1000000

void handle_error_timer (fsp_err_t err);

/* A free running execution timer getter.
 * procedure: construction, open, start, stop, get_time.
 */
uint32_t cmt_free_counter_freq_hz();
void cmt_free_counter_open();
void cmt_free_counter_start();
void cmt_free_counter_stop();
uint32_t cmt_free_counter_get_time(uint32_t timer_freq_hz);

/* The part of declaration can be moved to the header. */

void handle_error_timer (fsp_err_t err){}

uint32_t cmt_free_counter_freq_hz(){
    /* Get the source clock frequency (in Hz). There are several ways to do this in FSP:
     *  - Use the R_CMTW_InfoGet function (it accounts for the clock source and divider).
     *  - Calculate the current PCLKL frequency using R_FSP_SystemClockHzGet(FSP_PRIV_CLOCK_PCLKL) and right shift
     *    by timer_cfg_t::source_div.
     *
     * This example uses the last option (R_FSP_SystemClockHzGet).
     */
    return R_FSP_SystemClockHzGet(FSP_PRIV_CLOCK_PCLKL) >> g_timer0_cfg.source_div;
}

void cmt_free_counter_open(){
    /* Initializes the module. */
    fsp_err_t err = R_CMTW_Open(&g_timer0_ctrl, &g_timer0_cfg);
    handle_error_timer(err);

    /* Use the CMTW as a free running counter */
    err = R_CMTW_PeriodSet(&g_timer0_ctrl, 0xFFFFFFFF);
    handle_error_timer(err);
}

void cmt_free_counter_start(){
    R_CMTW_Start(&g_timer0_ctrl);
}

void cmt_free_counter_stop(){
    R_CMTW_Stop(&g_timer0_ctrl);
}

/* return the time interval between start and stop.
 * unit: microsecond (\mu s)
 */
uint32_t cmt_free_counter_get_time(uint32_t timer_freq_hz){
    uint32_t ans = 0;
    timer_status_t status;
    R_CMTW_StatusGet(&g_timer0_ctrl, &status);
    ans = (uint32_t) ((uint64_t) status.counter * TIMER_MIRCOSEC_PER_SEC / timer_freq_hz);
    return ans;
}
#include "model.h"
#include "weights.h"
#include "data_loader.h"
#include "inputs.h"
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>

/*******************************************************************************************************************//**
 * main() is generated by the FSP Configuration editor and is used to generate threads if an RTOS is used.  This function
 * is called by main() when no RTOS is used.
 **********************************************************************************************************************/
void hal_entry(void)
{
    /* TODO: add your own code here */
    setup_sci_uart();


    float* input_buffer = get_input();
    float* output_buffer = get_output();
    uint32_t exe_time;


    fixed_cyclic_loader(Inputs_fine_tune_data,
            input_buffer,NULL,NULL,
            0,1,2048);
    printf("Start Training!\n");
    cmt_free_counter_open();
    cmt_free_counter_start();
    forward(1, NULL);
    cmt_free_counter_stop();
    exe_time = cmt_free_counter_get_time(cmt_free_counter_freq_hz());
    printf("exe_Time: %d micro sec\n", (int)exe_time);

    printf("\n");
    for(int i=0; i<3; ++i){
        printf("%.5f ",output_buffer[i]);
    }
    printf("\n");


    printf("Start 800 Training!\n");
    cmt_free_counter_open();
    cmt_free_counter_start();
    for (int e=0; e<800; ++e){
        float total_loss=0.;
        int* batch_labels=(int*)malloc(MAX_BATCH_SIZE*sizeof(int));
        int batch_size=MAX_BATCH_SIZE;
        for (int index=0; index<TOTAL_SAMPLE_NUM; index+=MAX_BATCH_SIZE){
            batch_size = fixed_cyclic_loader(Inputs_fine_tune_data,
                                             input_buffer,Inputs_fine_tune_label,batch_labels,
                                             index,MAX_BATCH_SIZE,2048);


            total_loss+=batch_size*train(batch_labels,input_buffer,batch_size,2048,1e-4);
        }
        printf("epoch: %d, loss: %.7f\n", e, total_loss/TOTAL_SAMPLE_NUM);
    }
    cmt_free_counter_stop();
    exe_time = cmt_free_counter_get_time(cmt_free_counter_freq_hz());
    printf("exe_Time: %d micro sec\n", (int)exe_time);
}

/*******************************************************************************************************************//**
 * This function is called at various points during the startup process.  This implementation uses the event that is
 * called right before main() to set up the pins.
 *
 * @param[in]  event    Where at in the start up process the code is currently at
 **********************************************************************************************************************/
void R_BSP_WarmStart(bsp_warm_start_event_t event)
{
    if (BSP_WARM_START_RESET == event)
    {
        /* Pre clock initialization */
    }

    if (BSP_WARM_START_POST_C == event)
    {
        /* C runtime environment and system clocks are setup. */

        /* Configure pins. */
        R_IOPORT_Open (&g_ioport_ctrl, &g_bsp_pin_cfg);
    }
}
