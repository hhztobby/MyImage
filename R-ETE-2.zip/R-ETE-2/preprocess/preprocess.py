import os
import pandas as pd
import numpy as np
import tensorflow as tf
from scipy import fft # fast fourier
import matplotlib.pyplot as plt
from scipy.signal import stft # short-time 2048 256x8

def data_load(root_dir = os.path.join(".","training_data"),
                   time_stamps = 2048):
    csv_lists = os.listdir(root_dir)
    raw_data = np.empty([0, time_stamps], dtype=int)
    labels = np.empty([0, 1], dtype=int)
    for csv in csv_lists:
        csv_path = os.path.join(root_dir, csv)
        labels = np.concatenate([labels,np.array([[int(csv[0])]])], axis=0)
        feat = pd.read_csv(csv_path, names=["feat", "cls"])["feat"]
        feat = np.array(feat).reshape(1,-1)
        raw_data = np.concatenate([raw_data, feat], axis=0)
    cls_num = (max(labels)+1).item()
    # raw_data: [N, T], labels: [N, 1]
    return raw_data, labels, cls_num

# NN inputs shall be cast to [-1,1] or [0,1] to be effective.
def data_preprocess(feat):
    # in_shape: [N, T]
    # out_shape: [N, T]
    feat = np.array(feat, dtype=float)
    feat = feat / np.max(np.abs(feat), axis=-1, keepdims=True) # cast to [-1,1]
    freq = fft.fftfreq(feat.shape[1],d=1/1000)
    feat=np.abs(fft.fft(feat))
    feat = feat / np.max(np.abs(feat), axis=-1, keepdims=True) # cast to [0,1]
    return feat[:,:1024], freq[:1024]


def preprocess(feat, nperseg=128, sample_rate=5000):
    # Convert to NumPy array and cast to float
    feat = np.array(feat, dtype=float)

    # Normalize to the range [-1, 1]
    # feat = feat / np.max(np.abs(feat), axis=-1, keepdims=True)

    # Compute Short Time Fourier Transform (STFT)
    f, t, zxx = stft(
        feat,
        fs=sample_rate,
        window="hann",
        nperseg=nperseg,
        boundary=None
    )

    # Take absolute values of STFT output for magnitude
    zxx = np.abs(zxx)

    # Normalize to the range [0, 1]
    # zxx = zxx / np.max(np.abs(zxx), axis=-1, keepdims=True)

    # Return the first 1024 columns of the processed features and frequencies
    return zxx.transpose(0,2,1), f

def random_split(feat, labels, split_ratio=0.25):
    N=feat.shape[0]
    num=int(N*split_ratio)
    rand_perm=np.random.permutation(np.arange(0,N))
    feat=feat[rand_perm]
    labels=labels[rand_perm]
    return feat[num:], feat[:num], labels[num:], labels[:num]

def get_data(root_dir=os.path.join(".","training_data"),
                   time_stamps=2048):
    feat, labels, cls_num = data_load(root_dir,time_stamps)
    # feat, freq = data_preprocess(feat)
    feat, freq = preprocess(feat)
    return feat, labels, cls_num, freq

def get_train_data(root_dir=os.path.join(".","training_data"),
                   time_stamps=2048,
                   split_ratio=0.2):
    feat, labels, cls_num, freq = get_data(root_dir,time_stamps)
    train_feat, val_feat, train_labels, val_labels = random_split(feat,labels,split_ratio=split_ratio)
    return train_feat, val_feat, train_labels, val_labels, cls_num, freq

def plot_stft(t,f,amp):
    plt.close()
    plt.pcolormesh(t, f, amp, vmin=0, vmax=8000., shading='gouraud')
    plt.title('STFT Magnitude')
    plt.ylabel('Frequency [Hz]')
    plt.xlabel('Time [sec]')
    plt.show()
    plt.close()
    return

if __name__=="__main__":
    # feat, labels, cls_num = data_load()
    # feat, freq = data_preprocess(feat)
    train_feat, val_feat, train_labels, val_labels, cls_num, freq = get_data()
    print(val_labels.shape)
    # plot_stft(np.array([[1,2,3,4,5]]).reshape(5,1).repeat([1024],axis=1),
    #           freq.reshape(1,-1).repeat([5],axis=0),
    #           feat[100].reshape(1,-1).repeat([5],axis=0))
    # print(feat[100].reshape(1,-1))
    # print(feat.shape)
    with tf.device("CPU:0"):
        # generate data
        train_size=10
        test_size=10
        batch_size=1
        lr=1e-4
        nepoch=100
        train_set = tf.data.Dataset.from_tensor_slices((train_feat,train_labels))
        test_set = tf.data.Dataset.from_tensor_slices((val_feat,val_labels))

        # create datasets
        train_set = train_set.shuffle(buffer_size=train_size,
                                      reshuffle_each_iteration=True).batch(batch_size=batch_size)
        test_set = test_set.shuffle(buffer_size=test_size,
                                    reshuffle_each_iteration=True).batch(batch_size=batch_size)

        # create model

        # [B, 16, 65]
        model = tf.keras.Sequential([
            tf.keras.layers.Input((1024)),
            # tf.keras.layers.Dense(16,activation="relu"),
            tf.keras.layers.Dense(cls_num,activation="relu"),
            tf.keras.layers.Flatten()
        ])

        # compile the model
        model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=lr),
                      loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
                      metrics=tf.keras.metrics.CategoricalAccuracy(),
                      )
        model.summary()

        # fit the model
        history = model.fit(
            train_set,
            epochs=nepoch,
            validation_data=test_set,
            validation_freq=2
        )

        # visualize the history
        acc = history.history['categorical_accuracy']
        val_acc = history.history['val_categorical_accuracy']
        loss = history.history['loss']
        val_loss = history.history['val_loss']

        train_epochs_range = range(nepoch)
        val_epochs_range = range(0,nepoch,2)

        plt.figure(figsize=(8, 8))
        plt.subplot(1, 2, 1)
        plt.plot(train_epochs_range, acc, label='Training Accuracy')
        plt.plot(val_epochs_range, val_acc, label='Validation Accuracy')
        plt.legend(loc='lower right')
        plt.title('Training and Validation Accuracy')

        plt.subplot(1, 2, 2)
        plt.plot(train_epochs_range, loss, label='Training Loss')
        plt.plot(val_epochs_range, val_loss, label='Validation Loss')
        plt.legend(loc='upper right')
        plt.title('Training and Validation Loss')
        plt.savefig("./train_figure.png")
        plt.show()

        # Convert the model.
        converter = tf.lite.TFLiteConverter.from_keras_model(model)
        tflite_model = converter.convert()

        # Save the model.
        with open("pre_train.tflite", 'wb') as f:
            f.write(tflite_model)