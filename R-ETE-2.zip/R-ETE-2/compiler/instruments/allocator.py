
def allocate(nodes: list,
             peak_mem: int,
             buffer_size: int, 
             mem_budget: dict, 
             mem_budget_list: dict):
    """
    Individual name for each buffer.
    """
    preserved_input_pointer = 0
    train_aux_buffer_pointer = preserved_input_pointer + mem_budget["preserved_input_buffer"]
    input_output_pointer = train_aux_buffer_pointer + mem_budget["train_aux_buffer"]
    runtime_pointer = input_output_pointer + mem_budget["act_buffer"]
    input_state = True # If the input resides on the left?
    for idx,node in enumerate(nodes):
        if mem_budget_list["preserved_input_buffer"][idx]>0:
            # 1. assign input starter. 2. move the starter. 
            input_pointer=preserved_input_pointer
            preserved_input_pointer+=mem_budget_list["preserved_input_buffer"][idx]
        else:
            if input_state:
                input_pointer = input_output_pointer
            else:
                input_pointer = runtime_pointer - mem_budget_list["act_buffer"][idx-1]
            # toggle state for the next input position
            input_state = not input_state
        if mem_budget_list["act_buffer"][idx]==0:
            output_pointer=preserved_input_pointer
        else:
            # set the output_pointer to be the next input's pointer.
            if input_state:
                output_pointer = input_output_pointer
            else:
                output_pointer = runtime_pointer - mem_budget_list["act_buffer"][idx]
        mem_config_dict = {"input_pointer": input_pointer,
                            "output_pointer": output_pointer,
                            "runtime":runtime_pointer,
                            "train_aux_buffer":train_aux_buffer_pointer
                            }
        node.mem_config(mem_config_dict)
        train_aux_buffer_pointer += mem_budget_list["train_aux_buffer"][idx]
    return nodes[0].mem_config_dict["input_pointer"], output_pointer