from op.activations import Softmax_Impl
from op.node import dtype_size_map
import numpy as np

def no_trainable_prec(freeze_list: list,
                      id: int):
    return id<=(min(freeze_list) if len(freeze_list)>0 else 0)

def input_size(input_shape, max_batch_size):
    size = max_batch_size 
    for s in input_shape:
        size *= s
    return size

def schedule(nodes: list,
             freeze_list: list,
             input_sample_shape: list, # no batch_size
             inference_only=True,
             serialize_grad=False,
             max_batch_size=1):
    peak_mem = 0 # in Byte
    node_num = len(nodes)
    mem_budget = {"static":0,
                    "runtime":0,
                    "act_buffer":0,
                    "train_aux_buffer":0,
                    "preserved_input_buffer":0}
    mem_budget_list={"static":[],
                    "runtime":[],
                    "act_buffer":[],
                    "train_aux_buffer":[],
                    "preserved_input_buffer":[]}
    if isinstance(nodes[-1].activation, Softmax_Impl):
        if inference_only:
            nodes[-1].activation.scheme['inf']=True
        else:
            nodes[-1].activation.scheme["fuse_kldiv"]=True
    else:
        raise NotImplementedError
    act_input_shape=input_sample_shape
    for idx,node in enumerate(nodes):
        if not inference_only:
            node.scheme['weight_grad']=True
            node.scheme['bias_grad']=True
            node.scheme['grad_path']=True
            if idx in freeze_list:
                node.scheme['weight_grad']=False
                node.scheme['bias_grad']=False
            if no_trainable_prec(freeze_list, idx):
                node.scheme['grad_path']=False
        print(node.name, type(node))
        mem_dict, act_input_shape = node.mem_schedule(max_batch_size,
                                                      act_input_shape)
        for k in mem_dict.keys():
            mem_budget_list[k].append(mem_dict[k])
    mem_budget["runtime"]=max(mem_budget_list["runtime"])
    mem_budget["static"]=sum(mem_budget_list["static"])
    mem_budget["train_aux_buffer"]=sum(mem_budget_list["train_aux_buffer"])
    mem_budget["preserved_input_buffer"]=sum(mem_budget_list["preserved_input_buffer"])

    mem_budget["act_buffer"]=0
    cur_act_size = input_size(input_sample_shape,max_batch_size)*dtype_size_map[node.dtype] \
                     if mem_budget_list["preserved_input_buffer"][0]==0 else 0
    max_act_size = cur_act_size
    for j in range(0,node_num):
        if j+1 < node_num and mem_budget_list["preserved_input_buffer"][j+1]>0:
            # output need preserved!
            mem_budget_list["act_buffer"][j]=0
            cur_act_size = 0
        else:
            # no need to preserve output.
            max_act_size = max(max_act_size, cur_act_size+mem_budget_list["act_buffer"][j])
            cur_act_size = mem_budget_list["act_buffer"][j]
    mem_budget["act_buffer"] = max_act_size

    peak_mem = sum([m for _,m in mem_budget.items()])
    buffer_size = peak_mem - mem_budget["static"]

    shape_list = [node.input_sample_shape for node in nodes]
    shape_list.append(nodes[-1].output_sample_shape)
    return peak_mem, buffer_size, mem_budget, mem_budget_list, shape_list