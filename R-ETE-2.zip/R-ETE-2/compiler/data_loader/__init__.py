from .data_loader import FixedCyclicLoader

data_loader_map={
    "fixed_cyclic_loader": FixedCyclicLoader
}

__all__ = ["data_loader_map", "FixedCyclicLoader"]