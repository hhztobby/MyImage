import numpy as np
from op.node import Node

class DataLoader(object):
    def __init__(self) -> None:
        pass

    def serialize_loader(self,
                         header_file,
                         src_file):
        return 

class FixedCyclicLoader(DataLoader):
    prime_list=[3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271, 277, 281, 283, 293]
    def __init__(self, 
                 sample_num,
                 sample_size,
                 ) -> None:
        super().__init__()
        assert sample_num >= 4
        self.sample_num = sample_num
        self.sample_size = sample_size
        self.base = self.get_base()
        self.itr_list = np.array([i*self.base%self.sample_num for i in range(self.sample_num)])

    def get_base(self):
        for prime in FixedCyclicLoader.prime_list:
            if self.sample_num % prime != 0:
                return prime
            
    def serialize_loader(self,
                         header_name,
                         header_file,
                         src_file):
        header_str = ""
        src_str = ""
        header_str += "#ifndef DATA_LOADER_H_\n"
        header_str += "#define DATA_LOADER_H_\n\n"
        header_str += "#include <stdint.h>\n"
        header_str += "#define LOADER_BASE " + str(self.base) + "\n"
        header_str += "#define TOTAL_SAMPLE_NUM " + str(self.sample_num) + "\n"
        header_str += "extern int32_t fixed_cyclic_loader_itr_list[" + str(self.sample_num) + "];\n"
        header_str += "int fixed_cyclic_loader(float* total_samples, float* batch_buffer, int* total_labels, int* batch_labels, int index, int max_batch_size, int sample_size);\n"
        header_str += "\n#endif\n"

        src_str += "#include <stdint.h>\n#include <stddef.h>\n#include \"{header}\"\n\n".format(header=header_name)
        src_str += Node().serialize_np_array(self.itr_list,"fixed_cyclic_loader_itr_list")[1]
        src_str += "int fixed_cyclic_loader(float* total_samples, float* batch_buffer, int* total_labels, int* batch_labels, int index, int max_batch_size, int sample_size){\n"
        src_str += "\tfor (int b=index; b<index+max_batch_size && b<TOTAL_SAMPLE_NUM; ++b){\n" \
		        + "\t\tfloat* indexed_buffer = &total_samples[fixed_cyclic_loader_itr_list[b]*sample_size];\n" \
		        + "\t\tfor (int d=0; d<sample_size; ++d) batch_buffer[d]=indexed_buffer[d];\n" \
		        + "\t\tbatch_buffer += sample_size;\n" \
                + "\t\tif (total_labels!=NULL) batch_labels[b-index]=total_labels[fixed_cyclic_loader_itr_list[b]];\n" \
	            + "\t}\n" \
                + "\treturn (index+max_batch_size>TOTAL_SAMPLE_NUM)?(TOTAL_SAMPLE_NUM-index):max_batch_size;\n" \
                + "}\n"

        print(header_str, file=header_file)
        print(src_str, file=src_file)
        return 
    
if __name__ == "__main__":
    fine_tune_loader = FixedCyclicLoader(15, 2048)
    print(fine_tune_loader.itr_list)