#ifndef STFT_H_
#define STFT_H_

#include <stdint.h>

void stf_one(const float* x, 
            const float* window,
            float* runtime_buffer,
            float* stft_result, 
            int x_size, 
            int nperseg, 
            int noverlap, 
            int nfft ); // batch_size default to 1.

void stft(const float* x, 
            const float* window,
            float* runtime_buffer,
            float* stft_result, 
            int batch_size,
            int x_size, 
            int nperseg, 
            int noverlap, 
            int nfft );

#endif