#ifndef WEIGHT_H_
#define WEIGHT_H_

#include <stdint.h>

extern float stft_hann_window[128];
extern float conv1d_filter[1560];
extern float conv1d_bias[8];
extern float conv1d_1_filter[192];
extern float conv1d_1_bias[8];
extern float dense_weight[24];
extern float dense_bias[3];
#endif

