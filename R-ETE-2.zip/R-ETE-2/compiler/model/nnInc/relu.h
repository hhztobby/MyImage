#ifndef RELU_H_
#define RELU_H_

#include <stddef.h>
#include <stdint.h>

void relu_inf_in_place(float* input,
                    int8_t* bit_mask,
                    int batch_size,
                    int input_dim);

void relu_grad_path_in_place(float* grad,
                                int8_t* bit_mask,
                                int batch_size,
                                int input_dim);

#endif