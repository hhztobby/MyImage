#ifndef CONV1D_H_
#define CONV1D_H_

#include <stdint.h>

void conv1d_inf(float* input, //[batch_size, seq_len,ch_in]
                    float* filter, //[k, Cin, Cout]
                    float* bias, // [ch_out]
                    float* output, //[batch_size, new_seq_len, ch_out]
                    int batch_size, 
                    int ch_in,
                    int ch_out, 
                    int seq_len, 
                    int kenel_size,
                    int strides,
                    int pad_left,
                    int pad_right);

void conv1d_grad_path(float* grad_in,  //partial(L)/partial(Y) : [batch_size, new_seq_len, ch_out]
                    float* filter, //[kernel_size, ch_in, ch_out]
                    float* grad_out,  //partial(L)/partial(X) : [batch_size, seq_len, ch_in]
                    int batch_size, 
                    int ch_in,
                    int ch_out,
                    int seq_len,
                    int kernel_size,
                    int strides,
                    int pad_left,
                    int pad_right);

void conv1d_weight_grad(float* grad_in,  //partial(L)/partial(Y) : [batch_size, new_seq_len, ch_out]
                    float* input,
                    float* filter, // [kernel_size, ch_in, ch_out]
                    float* filter_grad,  // [kernel_size, ch_in, ch_out]
                    int batch_size, 
                    int ch_in,
                    int ch_out,
                    int seq_len,
                    int kernel_size,
                    int strides,
                    int pad_left,
                    int pad_right);

void conv1d_bias_grad(float* grad_in,  //partial(L)/partial(Y) : [batch_size, new_seq_len, ch_out]
                    float* input,
                    float* bias, // [kernel_size, ch_in, ch_out]
                    float* bias_grad,  // [kernel_size, ch_in, ch_out]
                    int batch_size, 
                    int ch_in,
                    int ch_out,
                    int seq_len,
                    int kernel_size,
                    int strides,
                    int pad_left,
                    int pad_right);

void conv1d_weight_sgd(float* weight,
                    float* weight_grad,
                    float lr,
                    int batch_size,
                    int kernel_size,
                    int ch_in,
                    int ch_out);

void conv1d_bias_sgd(float* bias,
                    float* bias_grad,
                    float lr,
                    int batch_size,
                    int ch_out);

#endif