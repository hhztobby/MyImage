#ifndef MAXPOOL1D_H_
#define MAXPOOL1D_H_

void maxpool1d_inf(float* input, //[batch_size, seq_len, ch] 
            float* output, //[batch_size, new_seq_len, ch]
            int* output_idx, //[batch_size, new_seq_len, ch]
            int batch_size,
            int seq_len,
            int pool_size,
            int ch,
            int strides, 
            int pad_left,
            int pad_right);

void maxpool1d_grad_path(float* grad_in, //[batch_size, new_seq_len, ch] 
            int* output_idx, //[batch_size, new_seq_len, ch] train_aux_buffer
            float* grad_out, //[batch_size, seq_len, ch]
            int batch_size,
            int seq_len,
            int pool_size,
            int ch,
            int strides, 
            int pad_left,
            int pad_right);

#endif
