#ifndef SOFTMAX_H_
#define SOFTMAX_H_

#include <stdint.h>
void softmax_inf(float* input,
                    float* output,
                    int batch_size,
                    int input_dim);
float fused_kldiv_softmax_inf_in_place(float* input,
                                int* ground_truth_idx,
                                int batch_size,
                                int input_dim);
void fused_kldiv_softmax_grad_path(float* input,
                                    int* ground_truth_idx,
                                    int batch_size,
                                    int input_dim);

#endif