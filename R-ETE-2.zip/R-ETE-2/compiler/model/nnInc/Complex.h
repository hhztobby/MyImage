#ifndef COMPLEX_H_
#define COMPLEX_H_
#include <math.h>

#define M_PI 3.14159265358979323846
typedef struct Complex {
    float real;
    float imag;
} Complex;


// Function to compute the nth root of unity
Complex conjugate_nth_root_of_unity(int n, int k);

// Function to multiply two complex numbers
Complex multiply_complex(Complex a, Complex b);

// Function to add two complex numbers
Complex add_complex(Complex a, Complex b);

// Function to add two complex numbers
Complex sub_complex(Complex a, Complex b);

#endif