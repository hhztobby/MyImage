#ifndef FC_H_
#define FC_H_

#include <stdint.h>

void fc_inf(float* input, 
                float* weight,
                float* bias,
                float* output,
                int batch_size,
                int input_middle_dim,
                int ch_in,
                int ch_out);

void fc_weight_grad(float* grad_in,
                    float* input,
                    float* weight, 
                    float* weight_grad,
                    int batch_size,
                    int input_middle_dim,
                    int ch_in,
                    int ch_out);

                
void fc_weight_sgd(float* weight,
                    float* weight_grad,
                    float lr,
                    int batch_size,
                    int ch_in,
                    int ch_out);

void fc_bias_grad(float* grad_in,
                    float* input,
                    float* bias,
                    float* bias_grad,
                    int batch_size,
                    int input_middle_dim,
                    int ch_in,
                    int ch_out);

void fc_bias_sgd(float* bias,
                    float* bias_grad,
                    float lr,
                    int batch_size,
                    int ch_out);

void fc_grad_path(float* grad_in,
                    float* weight,
                    float* grad_out,
                    int batch_size,
                    int input_middle_dim,
                    int ch_in,
                    int ch_out);       

#endif