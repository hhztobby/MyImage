#ifndef MODEL_H_
#define MODEL_H_

#include "weights.h"
#include <stdint.h>

#define MAX_BATCH_SIZE 5

extern int8_t buffer[92780];

float* get_input();
float* get_output();

float forward(int batch_size, int* ground_truth_idx);
#include <stddef.h>
#include "stft.h"
#include "weights.h"
#include "twiddle_tables.h"
#include "Complex.h"
#include <stddef.h>
#include "conv1d.h"
#include <stddef.h>
#include "relu.h"
#include <stddef.h>
#include "conv1d.h"
#include <stddef.h>
#include "relu.h"
#include <stddef.h>
#include "maxpool1d.h"
#include <stddef.h>
#include "fc.h"
#include <stddef.h>
#include "softmax.h"

void backward(int batch_size, int* ground_truth_idx, float lr);

float train(int* ground_truth_idx, float* training_data, int batch_size, int sample_size, float lr);
#endif

