#ifndef INPUTS_H_
#define INPUTS_H_

extern float Inputs_fine_tune_data[30720];
extern int Inputs_fine_tune_label[15];

#endif

