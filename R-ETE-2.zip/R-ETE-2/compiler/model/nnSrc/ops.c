#include "model.h"
#include <stdint.h>

int8_t buffer[92780];

float* get_input(){
	return (float*)(&buffer[44140]);
}
float* get_output(){
	return (float*)(&buffer[44140]);
}

float forward(int batch_size, int* ground_truth_idx){
	stft((float*)(&buffer[44140]), stft_hann_window, (float*)(&buffer[85100]), (float*)(&buffer[0]), batch_size, 2048, 128, 64, 128);
	conv1d_inf((float*)(&buffer[0]), conv1d_filter, conv1d_bias, (float*)(&buffer[40300]), batch_size, 65, 8, 31, 3, 2, 1, 1);
	relu_inf_in_place((float*)(&buffer[40300]), (int8_t*)(&buffer[43020]), batch_size, 128);
	conv1d_inf((float*)(&buffer[40300]), conv1d_1_filter, conv1d_1_bias, (float*)(&buffer[83820]), batch_size, 8, 8, 16, 3, 2, 0, 1);
	relu_inf_in_place((float*)(&buffer[83820]), (int8_t*)(&buffer[43660]), batch_size, 64);
	maxpool1d_inf((float*)(&buffer[83820]), (float*)(&buffer[42860]), (int*)(&buffer[43980]), batch_size, 8, 9, 8, 9, 0, 1);
	fc_inf((float*)(&buffer[42860]), dense_weight, dense_bias, (float*)(&buffer[44140]), batch_size, 1, 8, 3);
	float result = fused_kldiv_softmax_inf_in_place((float*)(&buffer[44140]), ground_truth_idx, batch_size, 3);
	return result;
}

float train(int* ground_truth_idx, float* training_data, int batch_size, int sample_size, float lr){
	float* net_input = get_input();
	if (net_input!=training_data){
		for(int d=0; d<sample_size*batch_size; ++d) net_input[d]=training_data[d];
	} // else the training data are loaded in place.
	float result=forward(batch_size, ground_truth_idx);
	backward(batch_size, ground_truth_idx, lr);
	return result;
}

void backward(int batch_size, int* ground_truth_idx, float lr){
	fused_kldiv_softmax_grad_path((float*)(&buffer[44140]), ground_truth_idx, batch_size, 3);
	fc_weight_grad((float*)(&buffer[44140]), (float*)(&buffer[42860]), dense_weight, (float*)(&buffer[85100]), batch_size, 1, 8, 3);
	fc_bias_grad((float*)(&buffer[44140]), (float*)(&buffer[42860]), dense_bias, (float*)(&buffer[85196]), batch_size, 1, 8, 3);
	fc_grad_path((float*)(&buffer[44140]), dense_weight, (float*)(&buffer[42860]), batch_size, 1, 8, 3);
	fc_weight_sgd(dense_weight, (float*)(&buffer[85100]), lr, batch_size, 8, 3);
	fc_bias_sgd(dense_bias, (float*)(&buffer[85196]), lr, batch_size, 3);
	maxpool1d_grad_path((float*)(&buffer[42860]), (int*)(&buffer[43980]), (float*)(&buffer[83820]), batch_size, 8, 9, 8, 9, 0, 1);
	relu_grad_path_in_place((float*)(&buffer[83820]), (int8_t*)(&buffer[43660]), batch_size, 64);
	conv1d_weight_grad((float*)(&buffer[83820]), (float*)(&buffer[40300]), conv1d_1_filter, (float*)(&buffer[85100]), batch_size, 8, 8, 16, 3, 2, 0, 1);
	conv1d_bias_grad((float*)(&buffer[83820]), (float*)(&buffer[40300]), conv1d_1_bias, (float*)(&buffer[85868]), batch_size, 8, 8, 16, 3, 2, 0, 1);
	conv1d_grad_path((float*)(&buffer[83820]), conv1d_1_filter, (float*)(&buffer[40300]), batch_size, 8, 8, 16, 3, 2, 0, 1);
	conv1d_weight_sgd(conv1d_1_filter, (float*)(&buffer[85100]), lr, batch_size, 3, 8, 8);
	conv1d_bias_sgd(conv1d_1_bias, (float*)(&buffer[85868]), lr, batch_size, 8);
	relu_grad_path_in_place((float*)(&buffer[40300]), (int8_t*)(&buffer[43020]), batch_size, 128);
	conv1d_weight_grad((float*)(&buffer[40300]), (float*)(&buffer[0]), conv1d_filter, (float*)(&buffer[85100]), batch_size, 65, 8, 31, 3, 2, 1, 1);
	conv1d_bias_grad((float*)(&buffer[40300]), (float*)(&buffer[0]), conv1d_bias, (float*)(&buffer[91340]), batch_size, 65, 8, 31, 3, 2, 1, 1);
	conv1d_grad_path((float*)(&buffer[40300]), conv1d_filter, (float*)(&buffer[0]), batch_size, 65, 8, 31, 3, 2, 1, 1);
	conv1d_weight_sgd(conv1d_filter, (float*)(&buffer[85100]), lr, batch_size, 3, 65, 8);
	conv1d_bias_sgd(conv1d_bias, (float*)(&buffer[91340]), lr, batch_size, 8);
}

