#include "fc.h"
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

/*  Input: [B, Cin]
    weight: [Cin, Cout]
    bias: [Cout] */     
void fc_inf(float* input, 
                float* weight,
                float* bias,
                float* output,
                int batch_size,
                int input_middle_dim,
                int ch_in,
                int ch_out){
                    // input: [batch_size, input_middle_dim, ch_in]
                    // weight: [ch_in, ch_out]
                    // bias: [ch_out]
                    // The input resides unchanged.
                    if (bias==NULL){
                        for(int i=0;i<input_middle_dim*batch_size;++i){
                            for(int k=0;k<ch_out;++k){
                                float sum=0.;
                                for(int j=0;j<ch_in;++j){
                                    sum += input[i*ch_in + j]*weight[j*ch_out + k];
                                }
                                output[i*ch_out + k] = sum;
                            }
                        }
                    }else{
                        for(int i=0;i<input_middle_dim*batch_size;++i){
                            for(int k=0;k<ch_out;++k){
                                float sum=bias[k];
                                for(int j=0;j<ch_in;++j){
                                    sum += input[i*ch_in + j]*weight[j*ch_out + k];
                                }
                                output[i*ch_out + k] = sum;
                            }
                        }
                    }
                }

void fc_weight_grad(float* grad_in,
                    float* input,
                    float* weight, 
                    float* weight_grad,
                    int batch_size,
                    int input_middle_dim,
                    int ch_in,
                    int ch_out){
                        // Not Fused.
                        // grad_in: [batch_size, input_middle_dim, ch_out]
                        // weight: [ch_in, ch_out]
                        // grad: (1/batch_size) * sum(grad)

                        // initialize weight gradient.
                        for(int i=0;i<ch_in;++i){
                            for(int j=0;j<ch_out;++j){
                                weight_grad[i*ch_out+j]=0.;
                            }
                        }
                        
                        // calculate weight gradient.
                        for (int b=0; b<batch_size; ++b){
                            for(int i=0;i<input_middle_dim;++i){
                                float* input_addr = &input[b*input_middle_dim*ch_in + i*ch_in];
                                float* grad_in_addr = &grad_in[b*input_middle_dim*ch_out + i*ch_out];
                                for(int c=0; c<ch_in; ++c){
                                    for(int f=0;f<ch_out;++f){
                                        weight_grad[c*ch_out+f] += (*input_addr) * (*grad_in_addr);
                                        grad_in_addr++;
                                    }
                                    grad_in_addr-=ch_out;
                                    input_addr++;
                                }
                            }
                        }
                    }


void fc_weight_sgd(float* weight,
                    float* weight_grad,
                    float lr,
                    int batch_size,
                    int ch_in,
                    int ch_out){
                        // Fuse Gradient and sgd update.
                        // grad_in: [input_middle_dim, ch_out]
                        // weight: [ch_in, ch_out]
                        float multiplier = lr;
                        for(int i=0;i<ch_in;++i){
                            for(int j=0;j<ch_out;++j){
                                weight[i*ch_out+j]-=weight_grad[i*ch_out+j]*multiplier;
                            }
                        }
                    }

void fc_bias_grad(float* grad_in,
                    float* input,
                    float* bias,
                    float* bias_grad,
                    int batch_size,
                    int input_middle_dim,
                    int ch_in,
                    int ch_out){
                        for (int f=0; f<ch_out; ++f){
                            bias_grad[f]=0.;
                        }
                        // reduce sum the grad_in. [input_middle_dim, ch_out]   
                        for (int b=0; b<batch_size; ++b){
                            for (int i=0; i<input_middle_dim; ++i){
                                for (int f=0; f<ch_out; ++f){
                                    bias_grad[f] += (*grad_in);
                                    grad_in++;
                                }
                            }
                        }
                    }


void fc_bias_sgd(float* bias,
                    float* bias_grad,
                    float lr,
                    int batch_size,
                    int ch_out){
                    float multiplier = lr;
                    for (int i=0; i<ch_out; ++i){
                        bias[i] -= bias_grad[i]*multiplier;
                    }
                }

void fc_grad_path(float* grad_in,
                    float* weight,
                    float* grad_out,
                    int batch_size,
                    int input_middle_dim,
                    int ch_in,
                    int ch_out){
                        // Not Fused!
                        // grad_in: [batch_size, input_middle_dim, ch_out]
                        // weight: [ch_in, ch_out]
                        // grad_out: [batch_size, input_middle_dim, ch_in]
                        for(int i=0;i<batch_size*input_middle_dim;++i){
                            float* grad_in_addr = &grad_in[i*ch_out];
                            float* weight_addr = weight;
                            for (int c=0; c<ch_in; ++c){
                                float sum = 0.;
                                for (int f=0; f<ch_out; ++f){
                                    sum += (*grad_in_addr) * (*weight_addr);
                                    grad_in_addr++;
                                    weight_addr++;
                                }
                                grad_in_addr-=ch_out;
                                grad_out[i*ch_in + c] = sum;
                            }
                        }
                    }