#include "maxpool1d.h"
#include <stddef.h>

void maxpool1d_inf(float* input, //[batch_size, seq_len, ch] 
            float* output, //[batch_size, new_seq_len, ch]
            int* output_idx, //[batch_size, new_seq_len, ch]
            int batch_size,
            int seq_len,
            int pool_size,
            int ch,
            int strides, 
            int pad_left,
            int pad_right)
{
    // Supports only zero padding.
    int new_seq_len = (int)((seq_len + pad_left + pad_right - pool_size) / strides) + 1;
    if (output_idx != NULL){
        for (int b = 0; b < batch_size; b++){
            for (int c = 0; c < ch; c++){
                int input_offset = b * seq_len * ch + c;
                int output_offset = b * new_seq_len * ch + c;
                for (int t = 0; t < new_seq_len; t++)
                {   
                    float maxx = 0., idx = -1;
                    int in_row = t * strides- pad_left;
                    if (in_row>=0){ 
                        maxx = input[input_offset + in_row*ch]; // otherwise 0 padded.
                        idx = input_offset + in_row*ch;
                    }
                    for (int k = 1; k < pool_size; ++k){
                        in_row++;
                        if (in_row<0 || in_row>=seq_len) continue;
                        if (input[input_offset + in_row*ch] > maxx){
                            maxx = input[input_offset + in_row*ch];
                            idx = input_offset + in_row*ch;
                        }
                    }
                    output[output_offset + t*ch] = maxx;
                    output_idx[output_offset + t*ch] = idx;
                }
            }
        }
    }else{
        for (int b = 0; b < batch_size; b++){
            for (int c = 0; c < ch; c++){
                int input_offset = b * seq_len * ch + c;
                int output_offset = b * new_seq_len * ch + c;
                for (int t = 0; t < new_seq_len; t++)
                {   
                    float maxx = 0.;
                    int in_row = t * strides- pad_left;
                    if (in_row>=0){ 
                        maxx = input[input_offset + in_row*ch]; // otherwise 0 padded.
                    }
                    for (int k = 1; k < pool_size; ++k){
                        in_row++;
                        if (in_row<0 || in_row>=seq_len) continue;
                        if (input[input_offset + in_row*ch] > maxx){
                            maxx = input[input_offset + in_row*ch];
                        }
                    }
                    output[output_offset + t*ch] = maxx;
                }
            }
        }
    }
}

void maxpool1d_grad_path(float* grad_in, //[batch_size, new_seq_len, ch] 
            int* output_idx, //[batch_size, new_seq_len, ch] train_aux_buffer
            float* grad_out, //[batch_size, seq_len, ch]
            int batch_size,
            int seq_len,
            int pool_size,
            int ch,
            int strides, 
            int pad_left,
            int pad_right)
{
    // Supports only zero padding.
    int new_seq_len = (int)((seq_len + pad_left + pad_right - pool_size) / strides) + 1;
    float* grad_out_offset = grad_out;
    for (int b = 0; b < batch_size; b++){
        for (int t = 0; t < seq_len; t++){
            for (int c = 0; c < ch; c++){
                (*grad_out_offset)=0.;
                grad_out_offset++;
            }
        }
    }
    for (int b = 0; b < batch_size; b++){
        for (int t = 0; t < new_seq_len; t++){
            for (int c = 0; c < ch; c++){
                if ((*output_idx)>=0){
                    grad_out[(*output_idx)]+=(*grad_in);
                }
                output_idx++;
                grad_in++;
            }
        }
    }
}