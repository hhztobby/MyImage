#include "Complex.h"
#include <math.h>

// Function to compute the nth root of unity
Complex conjugate_nth_root_of_unity(int n, int k) {
    float angle = 2 * M_PI * k / n;
    Complex w;
    w.real = cos(angle);
    w.imag = -sin(angle);
    return w;
}

// Function to multiply two complex numbers
Complex multiply_complex(Complex a, Complex b) {
    Complex result;
    result.real = a.real * b.real - a.imag * b.imag;
    result.imag = a.real * b.imag + a.imag * b.real;
    return result;
}

// Function to add two complex numbers
Complex add_complex(Complex a, Complex b) {
    Complex result;
    result.real = a.real + b.real;
    result.imag = a.imag + b.imag;
    return result;
}

// Function to add two complex numbers
Complex sub_complex(Complex a, Complex b) {
    Complex result;
    result.real = a.real - b.real;
    result.imag = a.imag - b.imag;
    return result;
}