#include "softmax.h"
#include <stdint.h>
#include <math.h>
#include <stddef.h>

void softmax_inf(float* input,
                    float* output,
                    int batch_size,
                    int input_dim){
                        // currently, only support softmax for the output layer.
                        for (int b=0; b<batch_size; ++b){
                            float sum = 0., multiplier = 0.;
                            for(int i=0; i<input_dim; ++i){
                                sum += exp(input[i]);
                            }
                            multiplier = 1 / sum;
                            for(int i=0; i<input_dim; ++i){
                                output[i] = exp(input[i])*multiplier;
                            }
                            input += input_dim;
                            output += input_dim;
                        }
                    }

/* The batch is divided on the loss function!!! */
float fused_kldiv_softmax_inf_in_place(float* input,
                                int* ground_truth_idx,
                                int batch_size,
                                int input_dim){
                        // currently, only support softmax for the output layer.
                        float loss = 0.;
                        for (int b=0; b<batch_size; ++b){
                            float sum = 0., multiplier=0.;
                            for(int i=0; i<input_dim; ++i){
                                sum += exp(input[i]);
                            }
                            if (ground_truth_idx!=NULL){
                                loss += -input[(*ground_truth_idx)] + log(sum);
                            }                        
                            multiplier = 1. / sum / batch_size;
                            for(int i=0; i<input_dim; ++i){
                                input[i] = exp(input[i]) * multiplier; // prepare for backpropagation.
                            }
                            input += input_dim;
                            ground_truth_idx++;
                        }
                        return loss / batch_size; // "reduction"=="batch_mean"
                    }

void fused_kldiv_softmax_grad_path(float* input,
                                    int* ground_truth_idx,
                                    int batch_size,
                                    int input_dim){
                        // currently, only support softmax for the output layer.
                        // input itself becomes gradient now.
                        for (int b=0; b<batch_size; ++b){
                            input[(*ground_truth_idx)] -= 1. / batch_size;
                            ground_truth_idx++;
                            input+=input_dim;
                        }
                    }