#include "stft.h"
#include "Complex.h"
#include "twiddle_tables.h"
#include "weights.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void FFTN(int bidx,
        int level,
        int lb, 
        float* input, 
        Complex* res,
        int MAX_LEVEL,
        int nfft,
        int ls0) {
    //bidx既是段的二进制编号，也是该段对应input的数据的起始序号
    //bidx位数 == level
    /*
    TODO:边界处理
    */
    if (level == MAX_LEVEL) {
        res[lb].real = input[bidx];
        res[lb].imag = 0;
        return;
    }

    //一般情况
    int n = (nfft >> level); //该层数据个数
    int mid = (lb + lb + n - 1) / 2;
    FFTN(bidx, level + 1, lb, input, res, MAX_LEVEL, nfft, ls0);
    FFTN(bidx + (1 << level), level + 1, mid + 1, input, res, MAX_LEVEL, nfft, ls0);
    //递归调用完后，res的[lb, mid],[mid+1, rb]已经有结果
    //接下来merge
    for (int k = lb; k <= mid; ++k) {
        // Compute the nth root of unity
        Complex w = (*(Complex*)(&twiddleCoef_2048[2*((k-lb)<<(ls0+level))]));
        // Combine the even and odd parts
        Complex t = multiply_complex(w, res[k + n / 2]);
        Complex o1 = add_complex(res[k], t);
        Complex o2 = sub_complex(res[k], t);
        res[k] = o1;
        res[k + n / 2] = o2;
    }
}

// STFT实现
void stft_one(const float* x, 
            const float* window,
            float* runtime_buffer,
            float* stft_result, 
            int x_size, 
            int nperseg, 
            int noverlap, 
            int nfft ) {
    float* input = runtime_buffer;
    Complex* res = (Complex*)(input + nfft);  // nfft
    int ls0 = log2(2048 / nfft);
    int MAX_LEVEL = log2(nfft);
    int num_segments = (x_size - noverlap) / (nperseg - noverlap);
    int nfft_half = nfft / 2 + 1;  // 计算单边频谱的大小

    for (int i = 0, pos = 0; pos <= x_size - nperseg; i++, pos += nperseg - noverlap) {
        for (int j = 0; j < nfft; j++) {
            input[j] = (j < nperseg && pos + j < x_size) ? x[pos + j] * window[j] : 0;
        }
        FFTN(0, 0, 0, input, res, MAX_LEVEL, nfft, ls0);

        float* row = &(stft_result[i * nfft_half]);
        // 仅保留单边频谱的部分
        for (int j = 0; j < nfft_half; j++){
            *(row++) = sqrt(res[j].real * res[j].real + res[j].imag * res[j].imag) * 2 / nperseg; // 计算幅度
        }
    }
}

// STFT实现
void stft(const float* x, 
            const float* window,
            float* runtime_buffer,
            float* stft_result, 
            int batch_size,
            int x_size, 
            int nperseg, 
            int noverlap, 
            int nfft ){
    int num_segments = (x_size - noverlap) / (nperseg - noverlap);
    int nfft_half = nfft / 2 + 1;  // 计算单边频谱的大小
    for (int b=0; b<batch_size; ++b){
        // stft one batch
        stft_one(x, window, runtime_buffer, stft_result, x_size, nperseg, noverlap, nfft);
        x += x_size;
        stft_result += num_segments*nfft_half;
    }
}