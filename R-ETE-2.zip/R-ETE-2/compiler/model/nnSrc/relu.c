#include "relu.h"
#include <stddef.h>
#include <stdint.h>

void relu_inf_in_place(float* input,
                    int8_t* bit_mask,
                    int batch_size,
                    int input_dim){
                        if (bit_mask==NULL){
                            for (int i=0; i<input_dim*batch_size; ++i){
                                input[i] = (input[i] >= 0.) ? input[i] : 0.;
                            }
                        }else{
                            for (int i=0; i<input_dim*batch_size; ++i){
                                if (input[i] >= 0.){
                                    bit_mask[i]=1;
                                }else{
                                    input[i]=0.;
                                    bit_mask[i]=0;
                                }
                            }
                        }
                    }

void relu_grad_path_in_place(float* grad,
                                int8_t* bit_mask,
                                int batch_size,
                                int input_dim){
                                    for (int i=0; i<input_dim*batch_size; ++i){
                                        if (!bit_mask[i]) grad[i]=0.;
                                    }
                                }
