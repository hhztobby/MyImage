#include "conv1d.h"
#include <stdio.h>
#include <stdlib.h>


void conv1d_inf(float* input, //[batch_size, seq_len,ch_in]
                    float* filter, //[k, Cin, Cout]
                    float* bias, // [ch_out]
                    float* output, //[batch_size, new_seq_len, ch_out]
                    int batch_size, 
                    int ch_in,
                    int ch_out, 
                    int seq_len, 
                    int kernel_size,
                    int strides,
                    int pad_left,
                    int pad_right) {
    // Supports only zero padding.
    int new_seq_len = (seq_len + pad_left + pad_right - kernel_size) / strides + 1;
    if (bias!=NULL){
        for (int b = 0; b < batch_size; b++){
            for (int t = 0; t < new_seq_len; ++t) {
                for (int f = 0; f < ch_out; ++f) {
                    float sum = bias[f];
                    for (int k = 0; k < kernel_size; ++k) {
                        int i =  t*strides + k - pad_left;

                        if (i<0 || i>=seq_len) continue;

                        float* in_addr = &input[b*seq_len*ch_in + i*ch_in];
                        float* filter_addr = &filter[k*ch_in*ch_out + f];

                        for (int c=0; c<ch_in; ++c){
                            sum += (*in_addr) * (*filter_addr);
                            in_addr++;
                            filter_addr+=ch_out;
                        }
                    }
                    output[b * new_seq_len * ch_out + t * ch_out + f]=sum;
                }
            }
        }
    }else{
        for (int b = 0; b < batch_size; b++){
            for (int t = 0; t < new_seq_len; ++t) {
                for (int f = 0; f < ch_out; ++f) {
                    float sum = 0.;
                    for (int k = 0; k < kernel_size; ++k) {
                        int i =  t*strides + k - pad_left;

                        if (i<0 || i>=seq_len) continue;

                        float* in_addr = &input[b*seq_len*ch_in + i*ch_in];
                        float* filter_addr = &filter[k*ch_in*ch_out + f];

                        for (int c=0; c<ch_in; ++c){
                            sum += (*in_addr) * (*filter_addr);
                            in_addr++;
                            filter_addr+=ch_out;
                        }
                    }
                    output[b * new_seq_len * ch_out + t * ch_out + f]=sum;
                }
            }
        }
    }
}

void conv1d_grad_path(float* grad_in,  //partial(L)/partial(Y) : [batch_size, new_seq_len, ch_out]
                    float* filter, //[kernel_size, ch_in, ch_out]
                    float* grad_out,  //partial(L)/partial(X) : [batch_size, seq_len, ch_in]
                    int batch_size, 
                    int ch_in,
                    int ch_out,
                    int seq_len,
                    int kernel_size,
                    int strides,
                    int pad_left,
                    int pad_right)
{
    //先求 grad_out
    int new_seq_len = (seq_len + pad_left + pad_right - kernel_size) / strides + 1;
    for (int b = 0; b < batch_size; b++){
        for (int i = 0; i < seq_len; i++){
            int k_base = (i+pad_left) % strides;
            int t_base = (i+pad_left) / strides;
            for (int c = 0; c < ch_in; c++){
                float sum = 0;
                for (int j = 0; (j*strides+k_base < kernel_size) && (t_base-j >= 0); j++){
                    float* grad_in_addr = &grad_in[b*new_seq_len*ch_out + (t_base-j)*ch_out];
                    float* filter_addr = &filter[(j*strides+k_base)*ch_in*ch_out + c*ch_out];
                    for (int f = 0; f < ch_out; f++){
                        sum += (*grad_in_addr) * (*filter_addr);
                        grad_in_addr++;
                        filter_addr++;
                    }
                }
                grad_out[b*seq_len*ch_in + i*ch_in + c] = sum;
            }
        }
    }
}

void conv1d_weight_grad(float* grad_in,  //partial(L)/partial(Y) : [batch_size, new_seq_len, ch_out]
                    float* input,
                    float* filter, // [kernel_size, ch_in, ch_out]
                    float* filter_grad,  // [kernel_size, ch_in, ch_out]
                    int batch_size, 
                    int ch_in,
                    int ch_out,
                    int seq_len,
                    int kernel_size,
                    int strides,
                    int pad_left,
                    int pad_right){
    // Supports only zero padding.
    for (int d=0; d<kernel_size*ch_in*ch_out; ++d){
        filter_grad[d]=0.;
    }
    int new_seq_len = (seq_len + pad_left + pad_right - kernel_size) / strides + 1;
    for (int b = 0; b < batch_size; b++){
        for (int t = 0; t < new_seq_len; ++t) {
            float* grad_in_addr = &grad_in[b*new_seq_len*ch_out + t*ch_out];
            for (int k = 0; k < kernel_size; ++k) {
                int i = t*strides + k - pad_left;
                float* filter_grad_addr = &filter_grad[k*ch_in*ch_out];
                if (i<0 || i>=seq_len) continue;
                float* in_addr = &input[b*seq_len*ch_in + i*ch_in];

                for (int c=0; c<ch_in; ++c){
                    for (int f = 0; f < ch_out; ++f) {                    
                        (*filter_grad_addr) += (*in_addr) * (*grad_in_addr);
                        filter_grad_addr++;
                        grad_in_addr++;
                    }
                    grad_in_addr-=ch_out;
                    in_addr++;
                }
            }
        }
    }
}

void conv1d_bias_grad(float* grad_in,  //partial(L)/partial(Y) : [batch_size, new_seq_len, ch_out]
                    float* input,
                    float* bias, // [kernel_size, ch_in, ch_out]
                    float* bias_grad,  // [kernel_size, ch_in, ch_out]
                    int batch_size, 
                    int ch_in,
                    int ch_out,
                    int seq_len,
                    int kernel_size,
                    int strides,
                    int pad_left,
                    int pad_right){
    // Supports only zero padding.
    for (int f=0; f<ch_out; ++f){
        bias_grad[f]=0.;
    }
    int new_seq_len = (seq_len + pad_left + pad_right - kernel_size) / strides + 1;
    for (int b = 0; b < batch_size; b++){
        for (int t = 0; t < new_seq_len; t++){
            for (int f = 0; f<ch_out; f++){
                bias_grad[f] += (*grad_in);
                grad_in++;
            }
        }
    }
}

void conv1d_weight_sgd(float* weight,
                    float* weight_grad,
                    float lr,
                    int batch_size,
                    int kernel_size,
                    int ch_in,
                    int ch_out){
    // weight: [kernel_size, ch_in, ch_out]
    float multiplier = lr;
    for(int i=0;i<kernel_size*ch_in*ch_out;++i){
        weight[i] -= weight_grad[i]*multiplier;
    }
}

void conv1d_bias_sgd(float* bias,
                    float* bias_grad,
                    float lr,
                    int batch_size,
                    int ch_out){
    // bias: [ch_out]
    float multiplier = lr;
    for (int i=0; i<ch_out; ++i){
        bias[i] -= bias_grad[i]*multiplier;
    }
}