import os
from .prefix_suffix import *
from op.inputs import Inputs
import shutil
from data_loader import data_loader_map

op_impl_path = "op_impl"

def handle_pp(node, 
              output_root:str):
    if hasattr(node,"activation") \
          and (node.activation is not None) \
              and node.activation.pp is not None:
        handle_pp(node.activation, output_root)
    pp = node.get_pp()
    if pp is None:
        return
    if pp["type"] == "impl":
        output_h_path=os.path.join(output_root, pp["header_path"])
        output_c_path=os.path.join(output_root, pp["src_path"])
        impl_h_path=os.path.join(op_impl_path, pp["header_path"])
        impl_c_path=os.path.join(op_impl_path, pp["src_path"])
        if not os.path.exists(output_h_path):
            shutil.copyfile(impl_h_path, output_h_path)
        if not os.path.exists(output_c_path):
            shutil.copyfile(impl_c_path, output_c_path)
        if "aux_path" in pp:
            for p in pp["aux_path"]:
                output_p_path=os.path.join(output_root, p)
                impl_p_path=os.path.join(op_impl_path, p)
                if not os.path.exists(output_p_path):
                    shutil.copyfile(impl_p_path, output_p_path)
    else:
        raise NotImplementedError
    return

def serialize_inputs(input_dict:dict,
                     ):
    input_node = Inputs(input_dict)
    header_str = "#ifndef INPUTS_H_\n#define INPUTS_H_\n\n"
    src_str = "#include \"inputs.h\"\n\n"
    input_header_str, input_src_str = input_node.serialize_weights()
    header_str += input_header_str
    src_str += input_src_str
    header_str += "\n#endif\n"
    return header_str, src_str
    

def serialize_weights(nodes):
    weights_header_str=weights_header_prefix(nodes)
    weights_src_str=weights_src_prefix(nodes)


    for node in nodes:
        header_str, src_str = node.serialize_weights()
        weights_header_str+=header_str
        weights_src_str+=src_str


    weights_header_str+=weights_header_suffix(nodes)
    weights_src_str+=weights_src_suffix(nodes)
    return weights_header_str, weights_src_str

def serialize_ops(output_root:str,
                  buffer_size: int, 
                  input_pointer: int,
                  output_pointer: int,
                  nodes: list,
                  mem_budget: dict,
                  max_batch_size=1):
    model_header_str=model_header_prefix(nodes, 
                                         buffer_size, 
                                         mem_budget,
                                         input_pointer,
                                         output_pointer,
                                         max_batch_size=max_batch_size)
    op_src_file_str=op_src_prefix(nodes, 
                                  buffer_size, 
                                  mem_budget,
                                  input_pointer,
                                  output_pointer)
    
    model_header_str+=model_header_inf_prefix(nodes)
    op_src_file_str+=op_src_inf_prefix(nodes)
    for node in nodes:
        handle_pp(node, output_root)
        header_str, src_str = node.serialize_inference()
        model_header_str+=header_str
        op_src_file_str+=src_str

    model_header_str+=model_header_inf_suffix(nodes)
    op_src_file_str+=op_src_inf_suffix(nodes)

    model_header_str+=model_header_grad_prefix(nodes)
    op_src_file_str+=op_src_grad_prefix(nodes)
    for idx in range(1,len(nodes)+1):
        node = nodes[-idx] # reversed order.
        header_str, src_str = node.serialize_backward()
        model_header_str+=header_str
        op_src_file_str+=src_str

    model_header_str+=model_header_grad_suffix(nodes)
    op_src_file_str+=op_src_grad_suffix(nodes)


    model_header_str+=model_header_suffix(nodes)
    op_src_file_str+=op_src_suffix(nodes)
    return model_header_str, op_src_file_str

def serialize_cmake_lists(nodes,
                          output_root,
                          backend):
    cmake_str = "add_library(model "
    for file_path in os.listdir(output_root):
        if file_path.split(".")[-1]=="c":
            cmake_str += file_path + ' '
    cmake_str += ")\n"

    for node in nodes:
        cmake_str += node.cmake_flags(backend)
    return cmake_str

def restructure_files(output_root: str):
    files = os.listdir(output_root)
    h_path = os.path.join(output_root, "nnInc")
    c_path = os.path.join(output_root, "nnSrc")
    os.makedirs(h_path)
    os.makedirs(c_path)
    for file in files:
        file_path = os.path.join(output_root, file)
        if file.endswith("h"):
            shutil.move(file_path,os.path.join(h_path,file))
        elif file.endswith("c"):
            shutil.move(file_path,os.path.join(c_path,file))
        else:
            continue
    return

def generate(output_root: str,
             buffer_size: int,
             input_pointer: int,
             output_pointer: int,
             nodes: list,
             mem_budget: dict,
             data_loader,
             input_dict={},
             backend="embedded",
             max_batch_size=1):
    # 0. output root.
    if os.path.exists(output_root):
        shutil.rmtree(output_root)
    os.makedirs(output_root, exist_ok=True)
    # 1. open writable output files.
    inputs_header_file = open(os.path.join(output_root, "inputs.h"),"wt")
    inputs_src_file = open(os.path.join(output_root, "inputs.c"),"wt")
    weights_header_file = open(os.path.join(output_root, "weights.h"),"wt")
    weights_src_file = open(os.path.join(output_root, "weights.c"),"wt")
    model_header_file = open(os.path.join(output_root, "model.h"),"wt")
    op_src_file = open(os.path.join(output_root, "ops.c"),"wt")
    cmake_file = open(os.path.join(output_root, "CMakeLists.txt"),"wt")
    data_loader_header_file_path = "data_loader.h"
    data_loader_header_file = open(os.path.join(output_root, "data_loader.h"),"wt")
    data_loader_src_file = open(os.path.join(output_root, "data_loader.c"),"wt")
    # 2. serializaion
    inputs_header_str, inputs_src_str = serialize_inputs(input_dict)
    weights_header_str, weights_src_str = serialize_weights(nodes)
    model_header_str, op_src_file_str = serialize_ops(output_root, 
                                                      buffer_size, 
                                                      input_pointer, 
                                                      output_pointer, 
                                                      nodes,
                                                      mem_budget,
                                                      max_batch_size=max_batch_size)
    data_loader.serialize_loader(data_loader_header_file_path,
                                 data_loader_header_file,
                                 data_loader_src_file)
    cmake_str = serialize_cmake_lists(nodes,output_root,backend)
    # 3. print
    print(inputs_header_str, file=inputs_header_file)
    print(inputs_src_str, file=inputs_src_file)
    print(weights_header_str, file=weights_header_file)
    print(weights_src_str, file=weights_src_file)
    print(model_header_str, file=model_header_file)
    print(op_src_file_str, file=op_src_file)
    print(cmake_str, file=cmake_file)
    # 3.5 close all files
    inputs_header_file.close()
    inputs_src_file.close()
    weights_header_file.close()
    weights_src_file.close()
    model_header_file.close()
    op_src_file.close()
    data_loader_header_file.close()
    data_loader_src_file.close()
    cmake_file.close()
    # 4. restructure files into headers and source.
    restructure_files(output_root)
    return