def weights_header_prefix(nodes):
    string = ""
    string += "#ifndef WEIGHT_H_\n#define WEIGHT_H_\n\n"
    string += "#include <stdint.h>\n\n"
    return string

def weights_src_prefix(nodes):
    string = ""
    string += "#include \"weights.h\"\n#include <stdint.h>\n\n"
    return string

def weights_header_suffix(nodes):
    string = ""
    string += "#endif\n"
    return string

def weights_src_suffix(nodes):
    string = ""
    return string


def handle_model_config(model_config=None) -> str:
    string = ""
    if isinstance(model_config, dict):
        if 'enable_neon' in model_config and model_config['enable_neon']==True:
            string += "#include <arm_neon.h>\n"
    return string

def model_header_prefix(nodes,
                        buffer_size: int,
                        mem_budget: dict,
                        input_pointer,
                        output_pointer,
                        model_config=None,
                        max_batch_size=1):
    string = ""
    string += "#ifndef MODEL_H_\n#define MODEL_H_\n\n"
    string += "#include \"weights.h\"\n"
    string += "#include <stdint.h>\n"
    string += handle_model_config(model_config)
    string += "\n"

    string += "#define MAX_BATCH_SIZE " + str(max_batch_size) + "\n\n"
    string += "extern int8_t buffer["+ str(buffer_size) +"];\n"
    string += "\n"

    string += "float* get_input();\n"
    string += "float* get_output();\n"
    return string

def op_src_prefix(nodes,
                  buffer_size: int,
                  mem_budget: dict, 
                  input_pointer,
                  output_pointer,
                  model_config=None):
    string = ""
    string += "#include \"model.h\"\n#include <stdint.h>\n"
    string += handle_model_config(model_config)
    string += "\n"

    string += "int8_t buffer["+ str(buffer_size) +"];\n"
    string += "\n"

    string += "float* get_input(){\n"
    string += "\treturn (float*)(&buffer[" + str(input_pointer) + "]);\n}\n"
    string += "float* get_output(){\n"
    string += "\treturn (float*)(&buffer[" + str(output_pointer) + "]);\n}\n"
    return string

def model_header_inf_prefix(nodes):
    string = ""
    string += "\nfloat forward(int batch_size, int* ground_truth_idx);\n"
    return string

def op_src_inf_prefix(nodes):
    string = ""
    string += "\nfloat forward(int batch_size, int* ground_truth_idx){\n"
    return string

def model_header_inf_suffix(nodes):
    string = ""
    return string

def op_src_inf_suffix(nodes):
    string = ""
    string += "\treturn result;\n}\n"
    return string

def model_header_grad_prefix(nodes):
    string = ""
    string += "\nvoid backward(int batch_size, int* ground_truth_idx, float lr);\n"
    string += "\nfloat train(int* ground_truth_idx, float* training_data, int batch_size, int sample_size, float lr);\n"
    return string


def op_src_grad_prefix(nodes):
    string = ""
    # train one batch
    string += "\nfloat train(int* ground_truth_idx, float* training_data, int batch_size, int sample_size, float lr){\n"
    string += "\tfloat* net_input = get_input();\n"
    string += "\tif (net_input!=training_data){\n"
    string += "\t\tfor(int d=0; d<sample_size*batch_size; ++d) net_input[d]=training_data[d];\n"
    string += "\t} // else the training data are loaded in place.\n"
    string += "\tfloat result=forward(batch_size, ground_truth_idx);\n"
    string += "\tbackward(batch_size, ground_truth_idx, lr);\n"
    string += "\treturn result;\n"
    string += "}\n"
    # backward definition
    string += "\nvoid backward(int batch_size, int* ground_truth_idx, float lr){\n"
    return string

def model_header_grad_suffix(nodes):
    string = ""
    return string

def op_src_grad_suffix(nodes):
    string = ""
    string += "}\n"
    return string

def model_header_suffix(nodes):
    string = ""
    string += "#endif\n"
    return string
    
def op_src_suffix(nodes):
    string = ""
    return string