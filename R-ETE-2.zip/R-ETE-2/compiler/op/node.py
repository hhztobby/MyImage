import numpy as np

dtype_map={
    np.dtype(np.float16): 'float',
    np.dtype(np.float32): 'float',
    np.dtype(np.float64): 'double',
    np.dtype(np.int8): 'int8_t',
    np.dtype(np.int16): 'int16_t',
    np.dtype(np.int32): 'int32_t',
    np.dtype(np.int64): 'int',
    'int': 'int',
    'int8': 'int8_t',
    'int16': 'int16_t',
    'int32': 'int32_t',
    'float': 'float',
    'float16': 'float',
    'float32': 'float',
}

dtype_size_map={
    np.dtype(np.float16): 4,
    np.dtype(np.float32): 4,
    np.dtype(np.float64): 8,
    np.dtype(np.int8): 1,
    np.dtype(np.int16): 2,
    np.dtype(np.int32): 4,
    'int': 4,
    'int8': 1,
    'int16': 2,
    'int32': 4,
    'float': 4,
    'float16': 4,
    'float32': 4,
}

class Node(object):
    def __init__(self) -> None:
        self.name=""
        self.scheme = {
            "grad_path": False,
            "weight_grad": False,
            "bias_grad": False,
            "preserve_input": False,
            "in_place_op": False
        } # default scheme
        self.mem_config_dict = None
        self.pp = None
        pass

    def serialize_np_array(self, array, array_name):
        if array is None:
            return ""
        array=array.flatten()
        size = len(array)
        dtype = dtype_map[array.dtype]
        name=self.name+("_" if self.name!="" else "")+array_name
        # deal with header first!
        header_str = "extern " + dtype + " "+ name + "[" + str(size) + "];\n"
        src_str = dtype + " "+ name + "[" + str(size) + "]={"
        src_str += ",".join([str(a) for a in array])
        src_str += "};\n"
        return header_str, src_str
    
    def sample_size(self, sample_shape, max_batch_size):
        size = max_batch_size 
        for s in sample_shape:
            size *= s
        return size
    
    def cmake_flags(self, backend):
        return ""

    def get_pp(self):
        return self.pp
    
    def mem_schedule(self, 
                     max_batch_size,
                     input_sample_shape):
        mem_dict = {"static":0,
                    "runtime":0,
                    "act_buffer":0,
                    "train_aux_buffer":0,
                    "preserved_input_buffer":0}
        return mem_dict, 0
    
    def mem_config(self, mem_config_dict):
        self.mem_config_dict = mem_config_dict
        return

    def serialize_weights(self):
        return "", ""
    
    def serialize_inference(self):
        return "", ""

    def serialize_backward(self):
        return "", ""
    
    def serialize_pointer(self, 
                          pointer,
                          cdtype="float"):
        return "({cdtype}*)(&buffer[{pointer}]), ".format(cdtype=cdtype,pointer=str(pointer))
    
    def merge_scheme(self, ego_scheme, other_scheme):
        # Only support in_place_op
        mem_dict = {"static":  ego_scheme["static"]+other_scheme["static"],# in Byte
                    "runtime": max(ego_scheme["runtime"], other_scheme["runtime"]), # in Byte
                    "act_buffer": ego_scheme["act_buffer"], # in Byte
                    "train_aux_buffer": ego_scheme["train_aux_buffer"]+other_scheme["train_aux_buffer"], # in Byte
                    "preserved_input_buffer": ego_scheme["preserved_input_buffer"] # in Byte
                    }
        return mem_dict