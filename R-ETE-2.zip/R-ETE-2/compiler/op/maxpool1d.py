from .activations import activation_map
from .node import Node, dtype_size_map

class MaxPool1D_Impl(Node):
    def __init__(self, op_config, op_weight) -> None:
        super().__init__()
        self.name = op_config['name']
        self.trainable = op_config['trainable']
        self.dtype = op_config['dtype']
        if "batch_input_shape" in op_config:
            self.batch_input_shape = op_config['batch_input_shape']
            self.input_sample_shape = list(self.batch_input_shape)
            self.input_sample_shape.pop(0) # pop out the first dim: batch.
        else:
            self.batch_input_shape = None
            self.input_sample_shape = None
        self.pool_size = op_config["pool_size"][0]
        self.strides = op_config["strides"][0] if "strides" in op_config else self.pool_size
        self.pad_type = op_config['padding'] # 'same'?
        self.odd_pad = op_config['odd_pad']
        self.channels_last = op_config['data_format']=='channel_last' # now only channel_last is supported!
        self.scheme['inplace_op'] = False
        self.pp = {"type": "impl",
                   "header_path": "maxpool1d.h",
                   "src_path": "maxpool1d.c"}
        pass

    def calc_padding(self):
        if self.pad_type == "valid":
            self.pad_left = 0
            self.pad_right = 0
            return
        elif self.pad_type == "same":
            pads = self.strides - (self.input_sample_shape[0] - self.pool_size) % self.strides
            if self.odd_pad == "right_more":
                self.pad_left = pads // 2
                self.pad_right = (pads+1) // 2
            else:
                self.pad_left = (pads+1) // 2
                self.pad_right = pads // 2
            return
        else:
            raise NotImplementedError
        
    def calc_output_seq_len(self):
        return (self.input_sample_shape[0]-self.pool_size+self.pad_left+self.pad_right)//self.strides + 1

    def mem_schedule(self,
                     max_batch_size,
                     input_sample_shape):
        # shape
        self.input_sample_shape = input_sample_shape
        self.max_batch_size = max_batch_size
        self.padding = self.calc_padding()
        self.input_sample_size = self.sample_size(self.input_sample_shape, 1)
        self.output_seq_len = self.calc_output_seq_len()
        self.output_sample_shape = self.input_sample_shape.copy()
        self.output_sample_shape.pop(0)
        self.output_sample_shape.insert(0,self.output_seq_len)
        self.output_sample_size = self.sample_size(self.output_sample_shape, 1)
        # word_len
        self.act_word_len = dtype_size_map[self.dtype]
        self.idx_word_len = dtype_size_map['int']
        # param_storage
        mem_dict = {"static":  0,# in Byte
                    "runtime": 0, # in Byte
                    "act_buffer": self.output_sample_size * self.max_batch_size * self.act_word_len, # in Byte
                    "train_aux_buffer": self.output_sample_size * self.max_batch_size * self.idx_word_len * int(self.scheme["grad_path"]), # in Byte
                    "preserved_input_buffer": 0 # in Byte
                    }
        # return
        return mem_dict, self.output_sample_shape.copy()

    def serialize_inference(self):
        header_str = ""
        src_str = ""
        header_str += "#include <stddef.h>\n#include \"{header}\"\n".format(header=self.pp["header_path"])
        # function call
        src_str += "\tmaxpool1d_inf("
        src_str += self.serialize_pointer(self.mem_config_dict["input_pointer"])
        src_str += self.serialize_pointer(self.mem_config_dict["output_pointer"])
        src_str += self.serialize_pointer(self.mem_config_dict["train_aux_buffer"], cdtype='int') if self.scheme["grad_path"] else "NULL, "
        src_str += "batch_size, "
        src_str += str(self.input_sample_shape[0]) + ", " + str(self.pool_size) + ", "
        src_str += str(self.input_sample_shape[1]) + ", "
        src_str += str(self.strides) + ", " + str(self.pad_left) + ", " +str(self.pad_right)
        src_str += ");\n"
        # return
        return header_str, src_str
    
    def serialize_backward(self):
        header_str = ""
        src_str = ""
        # function call
        src_str += "\tmaxpool1d_grad_path("
        src_str += self.serialize_pointer(self.mem_config_dict["output_pointer"])
        src_str += self.serialize_pointer(self.mem_config_dict["train_aux_buffer"], cdtype='int')
        src_str += self.serialize_pointer(self.mem_config_dict["input_pointer"])
        src_str += "batch_size, "
        src_str += str(self.input_sample_shape[0]) + ", " + str(self.pool_size) + ", "
        src_str += str(self.input_sample_shape[1]) + ", "
        src_str += str(self.strides) + ", " + str(self.pad_left) + ", " +str(self.pad_right)
        src_str += ");\n"
        # return
        return header_str, src_str