from .softmax import Softmax_Impl
from .relu import ReLU_Impl

activation_map = {
    'softmax': Softmax_Impl,
    'relu': ReLU_Impl
}