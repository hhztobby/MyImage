from .activations import activation_map
from .node import Node, dtype_size_map

class Dense_Impl(Node):
    """
    Input: [B, Cin]
    weight: [Cin, Cout]
    bias: [Cout]
    """
    def __init__(self, op_config, op_weight) -> None:
        super().__init__()
        self.name = op_config['name']
        self.trainable = op_config['trainable']
        self.dtype = op_config['dtype']
        self.activation = activation_map[op_config['activation']]()
        self.use_bias = op_config['use_bias']
        self.weight = op_weight[0]
        self.bias = op_weight[1] if self.use_bias else None
        self.weight_name = "weight"
        self.bias_name = "bias"
        self.scheme['inplace_op'] = False
        self.scheme['preserve_input'] = True
        self.pp = {"type": "impl",
                   "header_path": "fc.h",
                   "src_path": "fc.c"}
        pass

    def cmake_flags(self,backend):
        return self.activation.cmake_flags(backend)

    def mem_schedule(self,
                     max_batch_size,
                     input_sample_shape):
        self.scheme["bias_grad"] = self.scheme["bias_grad"] and self.use_bias
        # shape
        self.input_sample_shape = input_sample_shape
        self.max_batch_size = max_batch_size
        self.ch_in, self.ch_out = self.weight.shape
        self.input_sample_size = self.sample_size(self.input_sample_shape, 1)
        self.input_middle_dim = self.input_sample_size // self.ch_in
        self.output_sample_shape = self.input_sample_shape.copy()
        self.output_sample_shape.pop(-1)
        self.output_sample_shape.append(self.ch_out)
        self.output_sample_size = self.sample_size(self.output_sample_shape, 1)
        # word_len
        self.act_word_len = dtype_size_map[self.dtype]
        self.weight_word_len = dtype_size_map[self.weight.dtype]
        self.bias_word_len = dtype_size_map[self.bias.dtype] if self.use_bias else 0
        # param_storage
        inf_param_size = self.ch_in*self.ch_out*self.weight_word_len \
                            + self.ch_out*self.bias_word_len * int(self.use_bias)
        train_param_size = self.ch_in*self.ch_out*self.weight_word_len * int(self.scheme["weight_grad"]) \
                            + self.ch_out*self.bias_word_len * int(self.scheme["bias_grad"])
        mem_dict = {"static":  inf_param_size,# in Byte
                    "runtime": train_param_size, # in Byte
                    "act_buffer": self.output_sample_size * self.max_batch_size * self.act_word_len, # in Byte
                    "train_aux_buffer": 0, # in Byte
                    "preserved_input_buffer": self.input_sample_size * self.max_batch_size * self.act_word_len * int(self.scheme["weight_grad"]) # in Byte
                    }
        # activation information
        self.activation.scheme["inplace_op"]=True
        self.activation.scheme["grad_path"]=self.scheme["grad_path"] \
                                                 or self.scheme["weight_grad"] \
                                                    or self.scheme["bias_grad"]
        mem_dict = self.merge_scheme(mem_dict, self.activation.mem_schedule(max_batch_size,
                                                                            self.output_sample_size,
                                                                            self.act_word_len)[0])
        # return
        return mem_dict, self.output_sample_shape.copy()

    def serialize_weights(self):
        weight_header_str,weight_src_str = self.serialize_np_array(self.weight, self.weight_name)
        bias_header_str,bias_src_str = self.serialize_np_array(self.bias, self.bias_name)
        return weight_header_str+bias_header_str, weight_src_str+bias_src_str

    def serialize_inference(self):
        header_str = ""
        src_str = ""
        header_str += "#include <stddef.h>\n#include \"{header}\"\n".format(header=self.pp["header_path"])
        # function call
        src_str += "\tfc_inf("
        src_str += self.serialize_pointer(self.mem_config_dict["input_pointer"])
        src_str += self.name + "_" + self.weight_name + ", "
        src_str += (self.name + "_" + self.bias_name + ", ") if self.use_bias else "NULL, "
        src_str += self.serialize_pointer(self.mem_config_dict["output_pointer"])
        src_str += "batch_size, "
        src_str += str(self.input_middle_dim) + ", "
        src_str += str(self.ch_in) + ", " + str(self.ch_out)
        src_str += ");\n"
        # activation call
        act_header, act_src = self.activation.serialize_inference(self.output_sample_size, 
                                                                  self.mem_config_dict["output_pointer"], 
                                                                  self.mem_config_dict["runtime"], 
                                                                  self.mem_config_dict["train_aux_buffer"])
        header_str += act_header
        src_str += act_src
        # return
        return header_str, src_str

    def serialize_backward(self):
        header_str = ""
        src_str = ""
        # activation gradient path call
        if self.scheme["grad_path"] or self.scheme["weight_grad"] or self.scheme["bias_grad"]:
            act_header, act_src = self.activation.serialize_backward(self.output_sample_size, 
                                                                     self.mem_config_dict["output_pointer"],
                                                                     self.mem_config_dict["runtime"],
                                                                     self.mem_config_dict["train_aux_buffer"])
            header_str += act_header
            src_str += act_src    
        # weight -> bias -> grad_path
        if self.scheme["weight_grad"]:
            src_str += "\tfc_weight_grad("
            src_str += self.serialize_pointer(self.mem_config_dict["output_pointer"])
            src_str += self.serialize_pointer(self.mem_config_dict["input_pointer"])
            src_str +=  self.name + "_" + self.weight_name + ", "
            src_str += self.serialize_pointer(self.mem_config_dict["runtime"])
            src_str += "batch_size, "
            src_str += str(self.input_middle_dim) + ", "
            src_str += str(self.ch_in) + ", " + str(self.ch_out)
            src_str += ");\n"
        if self.scheme["bias_grad"]:
            src_str += "\tfc_bias_grad("
            src_str += self.serialize_pointer(self.mem_config_dict["output_pointer"])
            src_str += self.serialize_pointer(self.mem_config_dict["input_pointer"])
            src_str +=  self.name + "_" + self.bias_name + ", "
            src_str += self.serialize_pointer(self.mem_config_dict["runtime"]+self.weight.size*self.weight_word_len)
            src_str += "batch_size, "
            src_str += str(self.input_middle_dim) + ", "
            src_str += str(self.ch_in) + ", " + str(self.ch_out)
            src_str += ");\n"
        if self.scheme["grad_path"]:
            src_str += "\tfc_grad_path("
            src_str += self.serialize_pointer(self.mem_config_dict["output_pointer"])
            src_str += self.name + "_" + self.weight_name + ", "
            src_str += self.serialize_pointer(self.mem_config_dict["input_pointer"])
            src_str += "batch_size, "
            src_str += str(self.input_middle_dim) + ", "
            src_str += str(self.ch_in) + ", " + str(self.ch_out)
            src_str += ");\n"
        # weight & bias sgd 
        if self.scheme["weight_grad"]:
            src_str += "\tfc_weight_sgd("
            src_str +=  self.name + "_" + self.weight_name + ", "
            src_str += self.serialize_pointer(self.mem_config_dict["runtime"])
            src_str += "lr, "
            src_str += "batch_size, "
            src_str += str(self.ch_in) + ", " + str(self.ch_out)
            src_str += ");\n"
        if self.scheme["bias_grad"]:
            src_str += "\tfc_bias_sgd("
            src_str +=  self.name + "_" + self.bias_name + ", "
            src_str += self.serialize_pointer(self.mem_config_dict["runtime"]+self.weight.size*self.weight_word_len) 
            src_str += "lr, "
            src_str += "batch_size, "
            src_str += str(self.ch_out)
            src_str += ");\n"
        return header_str, src_str