from .node import Node, dtype_size_map
import numpy as np

def gen_hann(size):
    array = np.arange(size,dtype=np.float32)
    array = 0.5 * (1 - np.cos(2 * np.pi * array / size))
    return array

window_map = {
    "hann": gen_hann
}

class Stft_Impl(Node):
    """
    Input:
    weight: [Cin, Cout]
    bias: [Cout]
    """
    def __init__(self, op_config) -> None:
        super().__init__()
        self.name = op_config["name"]
        self.dtype = "float32"
        self.window_type = "hann"
        self.x_size = op_config['x_size']
        self.nperseg = op_config['nperseg']
        self.noverlap = op_config['noverlap'] if 'noverlap' in op_config else self.nperseg // 2
        self.nfft = op_config['nfft'] if 'nfft' in op_config else self.nperseg
        self.window = window_map[self.window_type](self.nperseg)
        self.weight_name = self.window_type + "_window"
        self.pp = {"type": "impl",
                    "header_path": "stft.h",
                    "src_path": "stft.c",
                    "aux_path": ["Complex.h", "Complex.c", "twiddle_tables.h", "twiddle_tables.c"]}
        pass

    def cmake_flags(self,
                    backend="embedded"):
        if backend=="windows":
            return ""
        return "target_link_libraries(model PUBLIC m)\n"

    def mem_schedule(self,
                     max_batch_size,
                     input_sample_shape):
        # shape
        self.input_sample_shape = input_sample_shape
        self.max_batch_size = max_batch_size
        self.input_sample_size = self.sample_size(self.input_sample_shape, 1)
        assert self.input_sample_size == self.x_size
        self.output_sample_shape = [(self.x_size - self.noverlap) // (self.nperseg - self.noverlap),
                                    self.nfft // 2 + 1]
        self.output_sample_size = self.sample_size(self.output_sample_shape, 1)
        # word_len
        self.act_word_len = dtype_size_map[self.dtype]
        self.weight_word_len = dtype_size_map[self.window.dtype]
        # param_storage
        mem_dict = {"static": self.nperseg * self.weight_word_len,# in Byte
                    "runtime": (2+1) * self.nfft * self.max_batch_size * self.act_word_len, # in Byte
                    "act_buffer": self.output_sample_size * self.max_batch_size * self.act_word_len, # in Byte
                    "train_aux_buffer": 0, # in Byte
                    "preserved_input_buffer": 0 # in Byte
                    }
        # return
        return mem_dict, self.output_sample_shape.copy() # output shape

    def serialize_weights(self):
        weight_header_str,weight_src_str = self.serialize_np_array(self.window, self.weight_name)
        return weight_header_str, weight_src_str

    def serialize_inference(self):
        header_str = ""
        src_str = ""
        header_str += "#include <stddef.h>\n#include \"stft.h\"\n#include \"weights.h\"\n#include \"twiddle_tables.h\"\n#include \"Complex.h\"\n"
        src_str += "\tstft"
        src_str += "("
        src_str += self.serialize_pointer(self.mem_config_dict["input_pointer"])
        src_str += self.name + "_" + self.weight_name + ", "
        src_str += self.serialize_pointer(self.mem_config_dict["runtime"])
        src_str += self.serialize_pointer(self.mem_config_dict["output_pointer"])
        src_str += "batch_size, "
        src_str += str(self.x_size) + ', '
        src_str += str(self.nperseg) + ', '
        src_str += str(self.noverlap) + ', '
        src_str += str(self.nfft)
        src_str += ");\n"
        return header_str, src_str