from .node import Node

class Inputs(Node):
    def __init__(self, input_dict) -> None:
        super().__init__()
        self.name="Inputs"
        self.input_dict = input_dict.item()

    def serialize_weights(self):
        header_str, src_str = "", ""
        for k,v in self.input_dict.items():
            h_str, s_str = self.serialize_np_array(v,k)
            header_str += h_str
            src_str += s_str
        return header_str, src_str