from .node import Node

class Softmax_Impl(Node):
    def __init__(self) -> None:
        super().__init__()
        self.pp = {"type": "impl",
                    "header_path": "softmax.h",
                    "src_path": "softmax.c"}
        self.scheme["in_place_op"] = True

    def mem_schedule(self,
                     max_batch_size,
                     output_sample_size,
                     act_word_len):
        return super().mem_schedule(max_batch_size,output_sample_size)
    
    def cmake_flags(self,backend):
        if backend=="windows":
            return ""
        return "target_link_libraries(model PUBLIC m)\n"

    def serialize_inference(self,
                            input_dim,
                            input_pointer,
                            runtime_pointer,
                            train_aux_pointer):
        header_str = ""
        src_str = ""
        header_str += "#include <stddef.h>\n#include \"{header}\"\n".format(header=self.pp["header_path"])

        src_str += "\t"
        src_str += "float result = fused_kldiv_" if self.scheme["grad_path"] else ""
        src_str += "softmax_inf_in_place("
        src_str += self.serialize_pointer(input_pointer)
        src_str += "ground_truth_idx, " if self.scheme["grad_path"] else "NULL, "
        src_str += "batch_size, " + str(input_dim)
        src_str += ");\n"
        return header_str, src_str
    
    def serialize_backward(self,
                            input_dim,
                            input_pointer,
                            runtime_pointer,
                            train_aux_pointer):
        header_str = ""
        src_str = ""
        src_str += "\tfused_kldiv_softmax_grad_path("
        src_str += self.serialize_pointer(input_pointer)
        src_str += "ground_truth_idx, batch_size, " + str(input_dim) + ");\n"
        return header_str, src_str