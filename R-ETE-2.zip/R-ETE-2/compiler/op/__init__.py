from .softmax import Softmax_Impl
from .relu import ReLU_Impl
from .conv1d import Conv1d_Impl
from .fc import Dense_Impl
from .maxpool1d import MaxPool1D_Impl
from .stft import Stft_Impl

op_name_map = {
    'softmax': Softmax_Impl,
    'relu': ReLU_Impl,
    'conv1d': Conv1d_Impl,
    'fc': Dense_Impl,
    'maxpool1d': MaxPool1D_Impl,
    'stft': Stft_Impl,
}