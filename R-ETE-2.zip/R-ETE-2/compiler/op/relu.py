from .node import Node

class ReLU_Impl(Node):
    def __init__(self) -> None:
        super().__init__()
        self.pp = {"type": "impl",
                    "header_path": "relu.h",
                    "src_path": "relu.c"}
        self.scheme["in_place_op"] = True

    def mem_schedule(self,
                     max_batch_size,
                     output_sample_size,
                     act_word_len):
        mem_dict = {"static": 0,# in Byte
            "runtime": 0, # in Byte
            "act_buffer": 0, # in Byte
            "train_aux_buffer": output_sample_size*max_batch_size*1, # in Byte
            "preserved_input_buffer": 0 # in Byte
            }
        return mem_dict, 0

    def serialize_inference(self,
                            input_dim,
                            input_pointer,
                            runtime_pointer,
                            train_aux_pointer):
        header_str = ""
        src_str = ""
        header_str += "#include <stddef.h>\n#include \"{header}\"\n".format(header=self.pp["header_path"])

        src_str += "\trelu_inf_in_place("
        src_str += self.serialize_pointer(input_pointer)
        src_str += self.serialize_pointer(train_aux_pointer, cdtype='int8_t') if self.scheme["grad_path"] else "NULL, "
        src_str += "batch_size, " + str(input_dim)
        src_str += ");\n"
        return header_str, src_str
    
    def serialize_backward(self,
                            input_dim,
                            input_pointer,
                            runtime_pointer,
                            train_aux_pointer):
        header_str = ""
        src_str = ""
        src_str += "\trelu_grad_path_in_place("
        src_str += self.serialize_pointer(input_pointer)
        src_str += self.serialize_pointer(train_aux_pointer, cdtype='int8_t')
        src_str += "batch_size, " + str(input_dim)
        src_str += ");\n"
        return header_str, src_str