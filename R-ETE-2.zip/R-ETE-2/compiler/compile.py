import os
from frontend import parse_h5, parse_json, parse_npy
from generation import generate
from instruments.scheduler import schedule
from instruments.allocator import allocate
from data_loader import FixedCyclicLoader
import argparse

if __name__=="__main__":
    parser = argparse.ArgumentParser()
    # python compile.py --in_model single-layer.h5
    parser.add_argument("--in_model", type=str, default="pre_train.h5")
    parser.add_argument("--sample_num", type=int, default=15)
    parser.add_argument("--batch_size", type=int, default=1)
    args = parser.parse_args()
    input_model_name = args.in_model
    max_batch_size = args.batch_size
    sample_num = args.sample_num

    # parse and generate
    freeze_list = []
    nodes = []
    input_dict = parse_npy(os.path.join("frontend_model","fine_tune.npy"))
    preprocess_nodes = parse_json(os.path.join("frontend_model","preprocess.json"))
    backbone_nodes = parse_h5(os.path.join("frontend_model",input_model_name))
    nodes.extend(preprocess_nodes)
    nodes.extend(backbone_nodes)

    peak_mem,buffer_size,mem_budget,mem_budget_list,shape_list=schedule(nodes, 
                                                                freeze_list, 
                                                                input_sample_shape=[2048], # input_size here!
                                                                inference_only=False,
                                                                max_batch_size=max_batch_size)
    print("\n\n\n")
    print("peak mem: ", peak_mem, "B", sep="")
    print("buffer size: ", buffer_size, "B", sep="")
    print("mem budget:\n",mem_budget,sep="")
    print("shape list:\n",shape_list,sep="")
    print("mem budget list:\n",mem_budget_list,sep="")
    input_pointer, output_pointer=allocate(nodes,
             peak_mem,
             buffer_size, 
             mem_budget, 
             mem_budget_list)
    data_loader = FixedCyclicLoader(sample_num=sample_num,
                                    sample_size=2048) # input_size here!
    generate("model", 
             buffer_size, 
             input_pointer,
             output_pointer, 
             nodes, 
             mem_budget,
             data_loader,
             input_dict,
             backend="embedded",
             max_batch_size=max_batch_size)