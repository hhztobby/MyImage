import os
import numpy as np

def parse(file_path: str):
    """
    Only support read in dict of numpy ndarray
    """
    if os.path.exists(file_path):
        return np.load(file_path, allow_pickle=True)
    else:
        return {}