import tensorflow as tf
import keras
from op.conv1d import Conv1d_Impl
from op.fc import Dense_Impl
from op.maxpool1d import MaxPool1D_Impl

def parse_conv1d(op,
                 weight):
    op_config = op.get_config()
    op_config["odd_pad"] = "right_more"
    return Conv1d_Impl(op_config,weight)

def parse_maxpool1d(op,
                    weight):
    op_config = op.get_config()
    op_config["odd_pad"] = "right_more"
    return MaxPool1D_Impl(op_config,weight)

def parse_fc(op,
             weight):
    return Dense_Impl(op.get_config(),weight)


ops_parser_map = {
    'conv1d': parse_conv1d,
    'maxpool1d': parse_maxpool1d,
    'dense': parse_fc
}