import os
import json
from .json_ops_parsers import ops_parser_map
from op import op_name_map

def parse(file_path: str):
    """
    Only support Sequential h5 models now.
    """
    nodes = []
    if os.path.exists(file_path):
        model=json.load(open(file_path,"rt"))
        for op in model:
            internal_op=ops_parser_map[op["layer_type"]](op)
            nodes.append(internal_op)
    return nodes

if __name__=="__main__":
    parse("/home/hzx/Desktop/ANL/renesas1.0/compiler/frontend_model/preprocess.json")