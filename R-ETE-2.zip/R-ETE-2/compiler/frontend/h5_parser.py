import os
import tensorflow as tf
import keras
from .h5_ops_parsers import ops_parser_map
from generation import generate

keras_layer_str_map={
    keras.src.layers.convolutional.conv1d.Conv1D: 'conv1d',
    keras.src.layers.pooling.max_pooling1d.MaxPooling1D: 'maxpool1d',
    keras.src.layers.core.dense.Dense: 'dense'
}

def parse(file_path: str):
    """
    Only support Sequential h5 models now.
    """
    nodes = []
    model=tf.keras.saving.load_model(file_path)
    ops=model.layers
    ops_list=[(keras_layer_str_map[type(op)],op) for op in ops]
    weight_list=[op.get_weights() for op in ops]
    for op,weight in zip(ops_list,weight_list):
        internal_op = ops_parser_map[op[0]](op[1],weight)
        nodes.append(internal_op)
    nodes[-1].is_output = True
    return nodes

if __name__=="__main__":
    nodes=parse("fine_tune.h5")
    generate("neural-network", nodes)