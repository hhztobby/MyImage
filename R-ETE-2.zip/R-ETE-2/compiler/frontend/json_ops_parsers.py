from op.stft import Stft_Impl

def parse_stft(op_config):
    return Stft_Impl(op_config)

ops_parser_map = {
    "stft": parse_stft
}