import tensorflow as tf
import keras
import numpy as np

if __name__=="__main__":
    test_data = (np.arange(0,16,1)*0.01).reshape(1,-1)
    print(test_data)
    model = tf.keras.models.Sequential()
    model.add(tf.keras.Input(shape=(16)))
    model.add(tf.keras.layers.Dense(3,activation="softmax"))
    model.compile(optimizer=tf.keras.optimizers.SGD(learning_rate=1e-3),
            loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=False),
            metrics=tf.keras.metrics.SparseCategoricalAccuracy(),
            )
    model.summary()
    keras.saving.save_model(model=model,filepath="single-layer.h5")
    res=model.predict(test_data)
    print(res,file=open("result_log_single_layer.txt","wt"))