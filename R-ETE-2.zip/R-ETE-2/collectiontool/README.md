```bash
python rz4.py -w 0 COM7 0 100 150
python rz4.py -w 0 COM7 1 100 150
python rz4.py -w 0 COM7 2 100 150
```