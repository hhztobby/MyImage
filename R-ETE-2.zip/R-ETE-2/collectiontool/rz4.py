import os
import csv
import numpy as np
import serial
import argparse
import time
import struct
import sys
import argparse

CFG_ITEMS = 1
CFG_BUF_LEN = 2048
CFG_SYNC_WORD = b'RNSS'
frames=512


class cMotor:
    def __init__(self):
        pass

    def open(self,port):
        self.ser = serial.Serial(port = port, baudrate = 115200, timeout=5,stopbits=1)

    def close(self):
        self.ser.close()

    def sendCommand(self , command):
        command +='\r'
        self.ser.write( command.encode("ASCII"))
        ret = ""
        gotError = False
        lineCount=0
        dataAll=[]
        while(1):
            c = self.ser.read(1)
            if c == b'>':
                break
            if c == b'?':
                gotError=True
                break
            ret += c.decode("ASCII")
        if gotError==True:
            ret="ERROR"
        return(ret)


    def sendPlay(self ):
        command ='RESULT'+'\r'
        self.ser.write( command.encode("ASCII"))
        gotError = False
        lineCount=0
        current=0
        while( True ):
            c=self.ser.read(1)
#            print(c.decode() )
            if c==b'R':
                break
        c = self.ser.read(3)
#        print("RNSS")
        c = self.ser.read(CFG_BUF_LEN *2)
        ret = np.frombuffer( c , dtype='int16' )
        c = self.ser.read(5)
#        print( c.decode() )

        print( ret )
        return(ret,c[-1:])


    def off(self):
        self.sendCommand("OFF")




motor = cMotor()
time.sleep(2)

def Pattern1(file_root,fileName,expectedNum):
    ret= motor.sendCommand("PREDICT")
    print( "SENDING PREDICT")
#    print( ret )
    ret ,c = motor.sendPlay()
    print("RESULT=",c)
    expected = struct.pack( '<b' , int( expectedNum )+ 0x30 )
    className = np.full( 2048 , "C"+chr( int( expectedNum ) + 0x30 ))
    trainingData = np.vstack( ( ret , className )).T
    np.savetxt( os.path.join(file_root, fileName) ,trainingData,fmt="%s",delimiter=",")
    if c!=expected:
        print("wrong")
        return True
    print( "correct")
    return False

if __name__=='__main__':
#     Pattern1( "test.csv" )
    parser = argparse.ArgumentParser( description='Data collection program for RZDemo')
    parser.add_argument( 'ComPort' , help='COM port file [com1]' )
    parser.add_argument( 'ExpectedResult' , help='Expected result [1]')
    parser.add_argument( 'StartIndex' , help='Start index of file [200]')
    parser.add_argument( 'EndIndex' , help='Start index of file [200]')
    parser.add_argument( '-w','--WrongOnly' , help='1:WrongOnly(Default) 0:Record all',default=1, type=int)
    parser.add_argument( '--root', type=str, default="./collected_data")
    args=parser.parse_args()
    rangeStart = int( args.StartIndex )
    rangeEnd = int( args.EndIndex )
    os.makedirs(args.root,exist_ok=True)
    for i in range(rangeStart,rangeEnd):
        motor.open(args.ComPort)
        fileName = args.ExpectedResult+"tama"
#        print( args.w )
        if args.WrongOnly:
            while( Pattern1(args.root,fileName+str(i)+".csv" ,args.ExpectedResult ) == False ):
                motor.close()
                time.sleep(1)
                motor.open(args.ComPort)
        else:
            Pattern1(args.root,fileName+str(i)+".csv" ,args.ExpectedResult)
        print(i)
        motor.close()
        time.sleep(1)
#    motor.off()