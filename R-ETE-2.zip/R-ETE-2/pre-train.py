import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
from preprocess.preprocess import get_data, get_train_data
import argparse
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv1D, Flatten, Dense


# generate data
train_size=10
test_size=10

def inference_one(input_details, output_details, interpreter, tensor):
    interpreter.allocate_tensors()
    
    interpreter.set_tensor(input_details[0]['index'], tensor)
    interpreter.invoke()
    out_res=interpreter.get_tensor(output_details[0]['index'])
    return out_res
    
def test_tflite(input_details, output_details, interpreter, tensor, labels):
    tensor=np.array(tensor,dtype=np.float32)
    items = len(tensor)
    succ = 0
    for t in range(items):
        output = inference_one(input_details, output_details, interpreter, np.expand_dims(tensor[t],axis=0))
        succ += np.argmax(output)==labels[t]
    return succ / items

def freeze_layers(model, frozen_layers):
    # rerturn a not compiled model with layer frozen.
    print(model.layers)
    for l in frozen_layers:
        model.layers[l].trainable = False
    print(model.layers[0].get_weights()[0].shape,model.layers[0].get_weights()[1].shape)
    return model

def train(train_set, 
          test_set, 
          model, 
          lr, 
          nepoch,
          fig_path="train_fig.png",
          optimizer="sgd"):
    # compile the model
    # sparseCategorical represents labels in dence way. Categorical applies one-hot repr.
    if optimizer=="sgd":
        model.compile(optimizer=tf.keras.optimizers.SGD(learning_rate=lr),
                    loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=False),
                    metrics=tf.keras.metrics.SparseCategoricalAccuracy(),
                    )
    else:
        model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=lr),
                loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=False),
                metrics=tf.keras.metrics.SparseCategoricalAccuracy(),
                )
    model.summary()

    # fit the model
    history = model.fit(
        train_set,
        epochs=nepoch,
        validation_data=test_set,
        validation_freq=2
    )

    # visualize the history
    acc = history.history['sparse_categorical_accuracy']
    val_acc = history.history['val_sparse_categorical_accuracy']
    loss = history.history['loss']
    val_loss = history.history['val_loss']

    train_epochs_range = range(nepoch)
    val_epochs_range = range(0,nepoch,2)

    plt.figure(figsize=(8, 8))
    plt.subplot(1, 2, 1)
    plt.plot(train_epochs_range, acc, label='Training Accuracy')
    plt.plot(val_epochs_range, val_acc, label='Validation Accuracy')
    plt.legend(loc='lower right')
    plt.title('Training and Validation Accuracy')

    plt.subplot(1, 2, 2)
    plt.plot(train_epochs_range, loss, label='Training Loss')
    plt.plot(val_epochs_range, val_loss, label='Validation Loss')
    plt.legend(loc='upper right')
    plt.title('Training and Validation Loss')
    plt.savefig(fig_path)
    plt.show()

    return model

def save_model(model,
               prefix="best_model"):
    # convert and save tflite model
    # Convert the model.
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    tflite_model = converter.convert()
    # Save the model.
    with open(prefix+".tflite", 'wb') as f:
        f.write(tflite_model)

    # save h5 model
    model.save(prefix+".h5")

if __name__=="__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--fine-tune", action="store_true", default=False)
    parser.add_argument("--test-only", action="store_true", default=False)
    parser.add_argument("--batchsize", type=int, default=40)
    parser.add_argument("--lr", type=float, default=6e-4)
    parser.add_argument("--epoch", type=int, default=3000)
    args = parser.parse_args()
    batch_size=args.batchsize
    lr=args.lr
    nepoch=args.epoch
    test_only=args.test_only
    fine_tune=args.fine_tune

    if test_only:
        test_feat, test_labels, cls_num, freq = get_data(root_dir="./collected_data")
        # test_feat, test_labels, cls_num, freq = get_data(root_dir="./train_large")


        loaded_model = tf.keras.saving.load_model("pre_train.h5")
        # loaded_model = tf.keras.saving.load_model("fine_tune.h5")
        items = len(test_feat)
        succ = 0
        for t in range(len(test_feat)):
            out_res = loaded_model.predict(test_feat[t:t+1])
            succ += test_labels[t]==np.argmax(out_res)
            print(test_labels[t],np.argmax(out_res))
            print(out_res)
        print(succ/items)

        # test inference effect on tflite.
        with tf.device("CPU:0"):
            interpreter = tf.lite.Interpreter("pre_train.tflite")
            # interpreter = tf.lite.Interpreter("fine_tune.tflite")
            input_details=interpreter.get_input_details()
            output_details=interpreter.get_output_details()
            print(input_details)
            print(output_details)
            interpreter.allocate_tensors()
            
            success_rate=test_tflite(input_details, output_details, interpreter, test_feat, test_labels)
            print(success_rate)
    else:
        if not fine_tune:
            train_feat, val_feat, train_labels, val_labels, cls_num, freq = get_train_data(root_dir="./train")
            # train_feat, val_feat, train_labels, val_labels, cls_num, freq = get_train_data(root_dir="./testing_data_ori")

            print(val_feat,val_labels)
            with tf.device("CPU:0"):
                train_set = tf.data.Dataset.from_tensor_slices((train_feat,train_labels))
                test_set = tf.data.Dataset.from_tensor_slices((val_feat,val_labels))

                # create datasets
                train_set = train_set.shuffle(buffer_size=train_size,
                                            reshuffle_each_iteration=True).batch(batch_size=batch_size)
                test_set = test_set.shuffle(buffer_size=test_size,
                                            reshuffle_each_iteration=True).batch(batch_size=batch_size)
                
                # create model
            
                # [B, 16, 65]
                # model = tf.keras.Sequential([
                #     tf.keras.layers.Input((1024)),
                #     tf.keras.layers.Dense(1), # left for fine-tuning.
                #     tf.keras.layers.Dense(cls_num,activation="softmax"),
                #     tf.keras.layers.Flatten()
                # ])

                # # 创建LSTM模型
                # model = tf.keras.Sequential()
                # model.add(LSTM(50, input_shape=(65, 33), return_sequences=True, data_format='channels_first'))
                # model.add(Dense(cls_num, activation='softmax'))  # 使用softmax激活函数适应多类别分类
                # model.add(tf.keras.layers.Flatten())

                # # 创建CNN模型
                # model = Sequential()
                # model.add(
                #     Conv1D(16, kernel_size=3, activation='relu', input_shape=(31, 65), data_format='channels_last',
                #            strides=2, padding='same'))
                # model.add(
                #     Conv1D(8, kernel_size=3, activation='relu', input_shape=(16, 16), data_format='channels_last',
                #            strides=2, padding='same'))
                # #
                # # model.add(
                # #     Conv1D(16, kernel_size=3, activation='elu', input_shape=(33, 65), data_format='channels_last',
                # #            strides=2, padding='same'))

                # model.add(tf.keras.layers.MaxPool1D(pool_size=9, padding='same'))
                # model.add(Dense(cls_num, activation='softmax'))

                # 创建CNN模型
                model = Sequential()
                model.add(
                    Conv1D(8, kernel_size=3, activation='relu', input_shape=(31, 65), data_format='channels_last',
                           strides=2, padding='same'))
                model.add(
                    Conv1D(8, kernel_size=3, activation='relu', input_shape=(16, 16), data_format='channels_last',
                           strides=2, padding='same'))
                #
                # model.add(
                #     Conv1D(16, kernel_size=3, activation='elu', input_shape=(33, 65), data_format='channels_last',
                #            strides=2, padding='same'))

                model.add(tf.keras.layers.MaxPool1D(pool_size=9, padding='same'))
                model.add(Dense(cls_num, activation='softmax'))

                model = train(train_set, test_set, model, lr, nepoch, "pre_train_fig.png", optimizer="adam")
                save_model(model, "pre_train")

                out_res = model.predict(train_feat[0:1])
                print(out_res)
                print(train_labels[0])
        else:
            # fine_tune
            train_feat, val_feat, train_labels, val_labels, cls_num, freq = get_train_data(root_dir="./testing_data_ori")
            # train_feat, val_feat, train_labels, val_labels, cls_num, freq = get_train_data(root_dir="./fine_tune_ori")
            with tf.device("CPU:0"):
                train_set = tf.data.Dataset.from_tensor_slices((train_feat,train_labels))
                test_set = tf.data.Dataset.from_tensor_slices((val_feat,val_labels))

                # create datasets
                train_set = train_set.shuffle(buffer_size=train_size,
                                            reshuffle_each_iteration=True).batch(batch_size=batch_size)
                test_set = test_set.shuffle(buffer_size=test_size,
                                            reshuffle_each_iteration=True).batch(batch_size=batch_size)
                
                loaded_model = tf.keras.saving.load_model("pre_train.h5")
                loaded_model=freeze_layers(loaded_model,[1,2])
                model=train(train_set, test_set, loaded_model, lr, nepoch, "fine_tune_fig.png", optimizer="sgd")

                save_model(model, "fine_tune")