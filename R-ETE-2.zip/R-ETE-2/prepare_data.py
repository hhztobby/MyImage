import os
import numpy as np
from preprocess.preprocess import data_load, random_split

fine_tune_size = 15

if __name__=="__main__":
    raw_data, labels, cls_num = data_load(os.path.join(".", "testing_data_ori"))
    total_points = raw_data.shape[0]
    fine_tune_data, fine_tune_label = [], []
    for j in range(cls_num):
        _, feat, _, label = random_split(raw_data[j*total_points//cls_num:(j+1)*total_points//cls_num],
                                   labels[j*total_points//cls_num:(j+1)*total_points//cls_num],
                                   (fine_tune_size+0.1)/total_points)
        print(feat.shape)
        fine_tune_data.append(feat)
        fine_tune_label.append(label)
    fine_tune_data = np.concatenate(fine_tune_data)
    fine_tune_label = np.concatenate(fine_tune_label)
    np.save(os.path.join("compiler","frontend_model","fine_tune"),
            {"fine_tune_data": np.array(fine_tune_data,dtype=np.float32),
             "fine_tune_label": np.array(fine_tune_label,dtype=np.int64)})