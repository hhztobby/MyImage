### 0. Environment
e2studio: v2023-01
rzt-fsp: v1.2.0
Download Link:
https://github.com/renesas/rzt-fsp/releases/download/v1.2.0/setup_rztfsp_v1_2_0_e2s_v2023-01.exe

~~~bash
conda create -n mlsys python=3.9
pip install -r requirements.txt
~~~

### 1. Data Collection
First, you shall collect abundant training data to feed the model.
~~~bash
python collectiontool/rz4.py -w 0 COM7 0 100 110
python collectiontool/rz4.py -w 0 COM7 1 100 110
python collectiontool/rz4.py -w 0 COM7 2 100 110
~~~

### 2. Train
Then, you train your model.
train
~~~bash
# python pre-train.py --batchsize 20 --lr 5e-4 --epoch 1500
python pre-train.py --batchsize 10 --lr 2e-4 --epoch 600
~~~

You can test your model on our provided original test set or fine_tune test set.
test
~~~bash
python pre-train.py --test-only
~~~

### 3. Compile
You first paste `pre-train.h5` into the `compile` folder. Then, you compile it. 
~~~bash
python compile.py --batch_size 5
~~~

fine-tune
~~~bash
python pre-train.py --fine-tune --batchsize 5 --lr 5e-4 --epoch 800
~~~

### Other Functions
~~~bash
python data_manager.py
~~~