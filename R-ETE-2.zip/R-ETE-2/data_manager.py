import os
import shutil
from tqdm import tqdm

def merge_dataset(dest_root,merge_roots=[],cls_num=3):
    max_idx=[100]*cls_num
    if os.path.exists(dest_root):
        dest_files = os.listdir(dest_root)
        for file in dest_files:
            cls_idx = int(file[0])
            sample_idx = int(file.split("tama")[1].split(".")[0])
            max_idx[cls_idx] = max(max_idx[cls_idx],sample_idx)
    os.makedirs(dest_root,exist_ok=True)
    for root in tqdm(merge_roots):
        if not os.path.exists(root):
            continue
        files = os.listdir(root)
        for file in files:
            cls_idx = int(file[0])
            max_idx[cls_idx]+=1
            ori_sample_idx = file.split("tama")[1].split(".")[0]
            new_file_name = file.replace(ori_sample_idx,str(max_idx[cls_idx]))
            dest_file_path = os.path.join(dest_root,new_file_name)
            shutil.copyfile(os.path.join(root, file),
                            dest_file_path)
    # [print("class: {cls_idx}, sample_num: {num}".format(cls_idx=idx,num=max_idx[idx]-100+1)) for idx in range(cls_num)]
    return

if __name__=="__main__":
    # merge_dataset("train", 
    #               ["raw_rai_data/training_data",
    #                "raw_rai_data/testing_data_ori",
    #                "raw_rai_data/testing_data_ori2",
    #                "collected_data"],
    #               cls_num=3)
    merge_dataset("train", 
                ["collected_data"],
                cls_num=3)