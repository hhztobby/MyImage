import tensorflow as tf
import tensorflow.keras as keras
import numpy as np
from scipy.signal import stft
from scipy import signal
import matplotlib.pyplot as plt

in_channels = 65 # shall be 2^n+1
stft_nperseg = (in_channels - 1) * 2
out_channels = 20
kernel_size = 3
stride = 3
in_timestamps = 16
sample_points = (in_timestamps-1) * (in_channels - 1)

train_size = 2000
test_size = 600

batch_size = 32
nepoch = 30
lr = 1e-4

Big = True

if Big:
    in_channels = 65 # shall be 2^n+1
    out_channels = 20
    kernel_size = 3
    stride = 3
    in_timestamps = 16
    model_file_name = "big_model.tflite"
else:
    in_channels = 2049
    out_channels = 1
    in_timestamps = 3
    model_file_name = "small_model.tflite"

stft_nperseg = (in_channels - 1) * 2
sample_points = (in_timestamps-1) * (in_channels - 1)

# in_shape: [N, T, C]
# out_shape: [N, 5, 20]

def generate_waveform(main_freq: int, abnormal_freq: int, num: int, sample_rate=5000):
    # unit: Hz
    time_interval = 1 / sample_rate
    x = np.linspace(0.0, num*time_interval, num, endpoint=False)
    main_wave = 2*np.sin(2*np.pi*main_freq*x+1e-4) 
    abnormal_wave = (np.random.random()+0.3)*np.sin(2*np.pi*abnormal_freq*x) if not (abnormal_freq is None) else 0.
    random_noise = 0.1*np.random.random(x.shape) - 0.05 + 0.1*np.random.randn(x.shape[0])
    return main_wave + abnormal_wave +random_noise

def preprocess(waveform, nperseg=128, sample_rate=5000):
    return stft(waveform,
         sample_rate,
         window="hamming",
         nperseg=nperseg)

def plot_stft(t,f,amp):
    plt.close()
    plt.pcolormesh(t, f, amp, vmin=0, vmax=2., shading='gouraud')
    plt.title('STFT Magnitude')
    plt.ylabel('Frequency [Hz]')
    plt.xlabel('Time [sec]')
    plt.show()
    plt.close()
    return

def generate_data(sample_size, sample_points, nperseg=128):
    features = []
    # abnormal samples
    for _ in range(sample_size // 2):
        waveform = generate_waveform(300, 450, num=sample_points)
        f, t, Zxx = preprocess(waveform, nperseg=nperseg)
        amp = np.abs(Zxx)
        features.append(amp.T.reshape(1,in_timestamps,in_channels))
        # print(f.shape)
        # print(t.shape)
        # print(amp.shape)
        # plot_stft(t,f,amp)
    plot_stft(t[:in_timestamps],f[:in_channels],features[0][0].T)
    # normal samples
    for _ in range((sample_size+1) // 2):
        waveform = generate_waveform(300, None, sample_points)
        f, t, Zxx = preprocess(waveform)
        amp = np.abs(Zxx)
        features.append(amp.T.reshape(1,in_timestamps,in_channels))
    features = np.concatenate(features,axis=0)
    print(features.shape)
    return features

if __name__=="__main__":
    with tf.device("CPU:0"):
        # generate data
        features = generate_data(train_size, sample_points=sample_points, nperseg=stft_nperseg)
        labels = tf.concat([tf.ones([train_size // 2, 1]),tf.zeros([train_size // 2, 1])],axis=0)
        train_set = tf.data.Dataset.from_tensor_slices((features,labels))
        features = generate_data(test_size, sample_points=sample_points, nperseg=stft_nperseg)
        labels = tf.concat([tf.ones([test_size // 2, 1]),tf.zeros([test_size // 2, 1])],axis=0)
        test_set = tf.data.Dataset.from_tensor_slices((features,labels))

        # create datasets
        train_set = train_set.shuffle(buffer_size=train_size,
                                      reshuffle_each_iteration=True).batch(batch_size=batch_size)
        test_set = test_set.shuffle(buffer_size=test_size,
                                    reshuffle_each_iteration=True).batch(batch_size=batch_size)
        
        # create model
        if Big:
            # [B, 16, 65]
            model = keras.Sequential([
                keras.layers.Conv1D(out_channels, 3, padding='same', activation='relu', input_shape=(in_timestamps, in_channels)),
                keras.layers.Conv1D(out_channels, 3, strides=3, activation='relu'),
                keras.layers.Conv1D(out_channels, 3, activation='relu'),
                keras.layers.Conv1D(1, 3, activation='relu'),
                keras.layers.Flatten()
            ])
        else:
            # input: [B, 3, 2049] (2049 for time complexity)
            model = keras.Sequential([
                keras.layers.Conv1D(1, 3, activation=None, input_shape=(in_timestamps, in_channels)),
                keras.layers.Flatten()
            ])
        
        # compile the model
        model.compile(optimizer=keras.optimizers.Adam(learning_rate=lr),
                      loss=keras.losses.BinaryCrossentropy(from_logits=False),
                      metrics=keras.metrics.BinaryAccuracy(),
                      )
        model.summary()

        # fit the model
        history = model.fit(
            train_set,
            epochs=nepoch,
            validation_data=test_set,
            validation_freq=2
        )

        # visualize the history
        acc = history.history['binary_accuracy']
        val_acc = history.history['val_binary_accuracy']
        loss = history.history['loss']
        val_loss = history.history['val_loss']

        train_epochs_range = range(nepoch)
        val_epochs_range = range(0,nepoch,2)

        plt.figure(figsize=(8, 8))
        plt.subplot(1, 2, 1)
        plt.plot(train_epochs_range, acc, label='Training Accuracy')
        plt.plot(val_epochs_range, val_acc, label='Validation Accuracy')
        plt.legend(loc='lower right')
        plt.title('Training and Validation Accuracy')

        plt.subplot(1, 2, 2)
        plt.plot(train_epochs_range, loss, label='Training Loss')
        plt.plot(val_epochs_range, val_loss, label='Validation Loss')
        plt.legend(loc='upper right')
        plt.title('Training and Validation Loss')
        plt.savefig("./train_figure.png")
        plt.show()

        # Convert the model.
        converter = tf.lite.TFLiteConverter.from_keras_model(model)
        tflite_model = converter.convert()
        
        # Save the model.
        with open(model_file_name, 'wb') as f:
            f.write(tflite_model)